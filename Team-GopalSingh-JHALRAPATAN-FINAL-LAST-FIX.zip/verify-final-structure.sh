#!/usr/bin/env bash
set -euo pipefail

fail() { echo "::error::$1"; exit 1; }

[ -f "package.json" ] || fail "package.json missing"
[ -f "package-lock.json" ] || fail "package-lock.json missing"
[ -f "server.js" ] || fail "server.js missing"
[ -d "client" ] || fail "client directory missing"
[ -f "client/index.html" ] || fail "client/index.html missing"

[ -d "android" ] || fail "android directory missing"
[ -f "android/settings.gradle.kts" ] || fail "android/settings.gradle.kts missing"
[ -f "android/app/build.gradle.kts" ] || fail "android/app/build.gradle.kts missing"

if [ ! -f "android/gradlew" ]; then
  echo "::warning::android/gradlew is missing; Android CI must bootstrap/use a pinned Gradle installation."
fi

[ -d ".github/workflows" ] || fail ".github/workflows missing"
echo "Final source structure verification: PASSED"
