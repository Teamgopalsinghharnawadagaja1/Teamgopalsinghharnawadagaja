// Top-level build file - plugin versions declared here, applied per-module.
// AGP version must track the Gradle version the CI workflow installs
// (currently Gradle 9.3.1) - AGP has a hard per-minor-version Gradle
// requirement from AGP 9.0 onwards.
plugins {
    id("com.android.application") version "9.3.0" apply false
}
