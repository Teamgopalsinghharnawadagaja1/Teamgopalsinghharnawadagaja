// Top-level build file - plugin versions declared here, applied per-module.
plugins {
    id("com.android.application") version "8.7.3" apply false
}
