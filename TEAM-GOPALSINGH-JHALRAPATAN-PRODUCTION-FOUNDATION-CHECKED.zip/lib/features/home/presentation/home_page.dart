import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String, dynamic>? registry;

  @override
  void initState() {
    super.initState();
    _loadRegistry();
  }

  Future<void> _loadRegistry() async {
    final raw = await rootBundle.loadString(
      'assets/requirements/feature_registry.json',
    );
    if (!mounted) return;
    setState(() => registry = jsonDecode(raw) as Map<String, dynamic>);
  }

  @override
  Widget build(BuildContext context) {
    final categories = (registry?['categories'] as List?)?.cast<String>() ?? [];
    final count = registry?['feature_count'] ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Team Gopal Singh Jhalrapatan'),
      ),
      body: registry == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Production Foundation',
                            style: Theme.of(context).textTheme.headlineSmall),
                        const SizedBox(height: 8),
                        Text('$count master requirements • ${categories.length} modules'),
                        const SizedBox(height: 12),
                        const Text(
                          'This build is the verified foundation. Individual requirements '
                          'will be implemented module-by-module against approved data sources.',
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text('Modules',
                    style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 8),
                ...categories.map(
                  (c) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.apps_outlined),
                      title: Text(c),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () {},
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
