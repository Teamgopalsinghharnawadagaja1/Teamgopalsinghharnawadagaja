import 'package:firebase_core/firebase_core.dart';

/// Firebase bootstrap point.
/// Do not commit private service-account keys.
/// After adding the generated FlutterFire configuration, call
/// Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform).
class FirebaseService {
  static Future<void> initialize() async {
    // Kept disabled until google-services.json / FlutterFire options
    // are installed in the repository.
    //
    // await Firebase.initializeApp(
    //   options: DefaultFirebaseOptions.currentPlatform,
    // );
  }

  static bool get isConfigured => Firebase.apps.isNotEmpty;
}
