class AppConfig {
  static const appName = 'Team Gopal Singh Jhalrapatan';
  static const packageName = 'com.teamgopalsingh.jhalrapatan';
  static const masterFeatureCount = 3312;
  static const masterCategoryCount = 50;
}
