import 'package:flutter/material.dart';
import '../features/home/presentation/home_page.dart';

class TeamGopalSinghApp extends StatelessWidget {
  const TeamGopalSinghApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Team Gopal Singh Jhalrapatan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorSchemeSeed: Colors.indigo,
      ),
      home: const HomePage(),
    );
  }
}
