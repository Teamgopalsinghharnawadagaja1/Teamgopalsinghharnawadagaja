# Team Gopal Singh Jhalrapatan

Production foundation for the Team Gopal Singh Jhalrapatan Android application.

## Master specification
The supplied Excel master list contains **3,312 requirements across 50 categories**. A machine-readable copy is included at:

`assets/requirements/feature_registry.json`

## Package
`com.teamgopalsingh.jhalrapatan`

## Stack
- Flutter
- Firebase (to be securely connected)
- GitHub Actions

## Build locally
```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

If this repository is first opened without the generated Android wrapper, run:

```bash
flutter create --platforms=android --org com.teamgopalsingh .
```

Then restore/verify the project files before building.

## Firebase
Do **not** commit service-account private keys. The Android Firebase configuration must match the package ID above.

## Scope
This repository is a production foundation, not a claim that all 3,312 requirements are already implemented. Requirements are tracked in the registry and will be delivered module-by-module with backend, security and tests.

## Validation note
This foundation intentionally does not contain Firebase credentials. Firebase is connected only after Android Firebase configuration is added securely. The CI workflow enforces the registered application ID `com.teamgopalsingh.jhalrapatan` when it generates the Android wrapper.
