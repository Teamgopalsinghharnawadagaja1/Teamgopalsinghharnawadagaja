# Production Implementation Plan

## Phase 0 — Foundation
- Flutter Android project
- Package ID: `com.teamgopalsingh.jhalrapatan`
- Feature registry generated from the master Excel
- GitHub Actions build pipeline
- Lint/test checks

## Phase 1 — Firebase
- Register Android app in Firebase
- Add `google-services.json` through a secure repository workflow
- Firebase Authentication
- Firestore
- Storage
- Cloud Messaging
- Security Rules
- Crash/error monitoring

## Phase 2 — Core application
- App shell/navigation
- Authentication and roles
- User profile
- Admin role/permission model
- Notifications
- Search
- Offline/online state
- Audit logging

## Phase 3 — Feature modules
Implement the 50 master categories in controlled batches. Every feature should have:
1. UI
2. Data model
3. Backend/API integration
4. Authorization
5. Validation
6. Automated test
7. Verification/source reference where applicable

## Phase 4 — Release
- Debug APK for internal testing
- Signed release AAB
- Play Console release
- Crash monitoring
- Backup/restore
- Security review

> Important: the 3,312 rows are requirements, not 3,312 independent screens. Multiple requirements can share screens, services, and data models.
