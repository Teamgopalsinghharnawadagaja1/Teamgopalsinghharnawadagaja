package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyPrimary

data class NavItem(
    val titleHindi: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@Composable
fun BottomNavigationBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        NavItem("होम", Icons.Filled.Home, Icons.Outlined.Home),
        NavItem("विकास", Icons.Filled.Engineering, Icons.Outlined.Engineering),
        NavItem("शिकायत", Icons.Filled.AssignmentTurnedIn, Icons.Outlined.Assignment),
        NavItem("AI सहायक", Icons.Filled.SmartToy, Icons.Outlined.SmartToy),
        NavItem("गांव सूची", Icons.Filled.HolidayVillage, Icons.Outlined.HolidayVillage)
    )

    NavigationBar(
        modifier = modifier.windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = NavyPrimary,
        tonalElevation = 8.dp
    ) {
        items.forEachIndexed { index, item ->
            val isSelected = selectedTab == index
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(index) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.titleHindi,
                        tint = if (isSelected) NavyPrimary else Color.White.copy(alpha = 0.7f)
                    )
                },
                label = {
                    Text(
                        text = item.titleHindi,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) GoldAccent else Color.White.copy(alpha = 0.7f)
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = GoldAccent
                )
            )
        }
    }
}
