package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Complaint
import com.example.data.models.ComplaintStatus
import com.example.ui.theme.NavyPrimary

@Composable
fun ComplaintCard(
    complaint: Complaint,
    isAdminMode: Boolean = false,
    onUpdateStatusClick: ((Complaint) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var showTimelineDialog by remember { mutableStateOf(false) }

    val statusEnum = try {
        ComplaintStatus.valueOf(complaint.status)
    } catch (e: Exception) {
        ComplaintStatus.RECEIVED
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { showTimelineDialog = true },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // ID and Status Badge Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = NavyPrimary.copy(alpha = 0.08f)
                ) {
                    Text(
                        text = "आंतरिक संदर्भ ID: ${complaint.id}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    shape = CircleShape,
                    color = Color(statusEnum.colorHex).copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(statusEnum.colorHex))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(Color(statusEnum.colorHex))
                        )
                        Text(
                            text = statusEnum.labelHindi,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(statusEnum.colorHex)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Village & Category info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Village",
                        tint = Color(0xFFE65100),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = complaint.villageName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFF1F5F9)
                ) {
                    Text(
                        text = "विषय: ${complaint.category}",
                        fontSize = 12.sp,
                        color = Color(0xFF475569),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Description
            Text(
                text = complaint.description,
                fontSize = 13.sp,
                color = Color(0xFF334155),
                maxLines = 3,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            HorizontalDivider(color = Color(0xFFE2E8F0))

            Spacer(modifier = Modifier.height(8.dp))

            // Citizen name, Date & Action Row
            val maskedMobile = if (complaint.mobileNumber.length >= 10) {
                complaint.mobileNumber.take(2) + "******" + complaint.mobileNumber.takeLast(2)
            } else {
                complaint.mobileNumber
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "आवेदक: ${complaint.citizenName} ($maskedMobile)",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = "दर्ज तिथि: ${complaint.dateFiled}",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (isAdminMode && onUpdateStatusClick != null) {
                        OutlinedButton(
                            onClick = { onUpdateStatusClick(complaint) },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("स्टेटस बदलें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = { showTimelineDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("ट्रैक करें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Live Tracking Progress Timeline Dialog Modal
    if (showTimelineDialog) {
        AlertDialog(
            onDismissRequest = { showTimelineDialog = false },
            confirmButton = {
                TextButton(onClick = { showTimelineDialog = false }) {
                    Text("बंद करें", fontWeight = FontWeight.Bold, color = NavyPrimary)
                }
            },
            title = {
                Column {
                    Text(
                        text = "जनसमस्या लाइव स्थिति",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Text(
                        text = "आईडी: ${complaint.id}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF8FAFC),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("गांव: ${complaint.villageName} | विषय: ${complaint.category}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("विवरण: ${complaint.description}", fontSize = 12.sp, color = Color.DarkGray)
                        }
                    }

                    Text("प्रगति स्थिति रेखा (Timeline):", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    val steps = listOf(
                        ComplaintStatus.RECEIVED,
                        ComplaintStatus.INVESTIGATING,
                        ComplaintStatus.DEPT_SENT,
                        ComplaintStatus.IN_PROGRESS,
                        ComplaintStatus.RESOLVED
                    )

                    val currentIndex = steps.indexOf(statusEnum).let { if (it == -1) 0 else it }

                    steps.forEachIndexed { idx, step ->
                        val isDone = idx <= currentIndex
                        val isCurrent = idx == currentIndex

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isDone) Color(step.colorHex) else Color.LightGray
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isDone) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Done",
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                } else {
                                    Text("${idx + 1}", fontSize = 11.sp, color = Color.White)
                                }
                            }

                            Column {
                                Text(
                                    text = step.labelHindi,
                                    fontSize = 13.sp,
                                    fontWeight = if (isCurrent) FontWeight.ExtraBold else FontWeight.Normal,
                                    color = if (isDone) Color.Black else Color.Gray
                                )
                                if (isCurrent) {
                                    Text(
                                        text = complaint.remarks,
                                        fontSize = 11.sp,
                                        color = Color(step.colorHex),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        )
    }
}
