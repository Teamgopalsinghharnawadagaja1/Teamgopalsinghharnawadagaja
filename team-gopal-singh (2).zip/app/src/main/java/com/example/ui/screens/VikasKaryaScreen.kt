package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.VikasKarya
import com.example.data.models.VikasStatus
import com.example.ui.components.VikasKaryaCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SaffronOrange
import com.example.viewmodel.MainViewModel

@Composable
fun VikasKaryaScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val vikasKaryaList by viewModel.vikasKarya.collectAsState()
    val statusFilter by viewModel.vikasStatusFilter.collectAsState()
    val isAdminMode by viewModel.isAdminMode.collectAsState()

    var showAddProjectDialog by remember { mutableStateOf(false) }

    val filteredList = vikasKaryaList.filter { project ->
        statusFilter == "सभी" || project.status == statusFilter
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color(0xFFF8FAFC),
        floatingActionButton = {
            if (isAdminMode) {
                FloatingActionButton(
                    onClick = { showAddProjectDialog = true },
                    containerColor = NavyPrimary,
                    contentColor = GoldAccent
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Project")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header Title
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyPrimary)
                    .padding(16.dp)
            ) {
                Text(
                    text = "क्षेत्रीय विकास कार्य ट्रैकर",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "झालावाड़ • झालरापाटन 198 एवं हरनावदा गजा प्रोजेक्ट्स",
                    fontSize = 12.sp,
                    color = GoldAccent
                )
            }

            // Summary Stats Banner Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val total = vikasKaryaList.size
                    val completed = vikasKaryaList.count { it.status == VikasStatus.COMPLETED.name }
                    val ongoing = vikasKaryaList.count { it.status == VikasStatus.IN_PROGRESS.name }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "$total", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = NavyPrimary)
                        Text(text = "कुल कार्य", fontSize = 11.sp, color = Color.Gray)
                    }
                    VerticalDivider(modifier = Modifier.height(24.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "$ongoing", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF2563EB))
                        Text(text = "निर्माणाधीन", fontSize = 11.sp, color = Color.Gray)
                    }
                    VerticalDivider(modifier = Modifier.height(24.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "$completed", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF16A34A))
                        Text(text = "पूर्ण कार्य", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }

            // Filter Tabs
            val filters = listOf(
                "सभी" to "सभी",
                "निर्माणाधीन" to VikasStatus.IN_PROGRESS.name,
                "पूर्ण" to VikasStatus.COMPLETED.name,
                "स्वीकृत" to VikasStatus.PLANNED.name
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filters) { (label, statusVal) ->
                    val isSelected = statusFilter == statusVal
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setVikasStatusFilter(statusVal) },
                        label = { Text(label, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NavyPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Projects List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredList) { vikas ->
                    VikasKaryaCard(vikasKarya = vikas)
                }
            }
        }
    }

    // Admin Add New Project Dialog
    if (showAddProjectDialog) {
        var title by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("सड़क") }
        var villageName by remember { mutableStateOf("हरनावदा गजा") }
        var budget by remember { mutableStateOf("₹ 25 लाख") }
        var description by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddProjectDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            viewModel.addNewVikasKarya(title, category, villageName, budget, description)
                            showAddProjectDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("जोड़ें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddProjectDialog = false }) {
                    Text("रद्द करें")
                }
            },
            title = { Text("नया विकास कार्य जोड़ें", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("परियोजना का नाम *") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("विभाग / श्रेणी (सड़क, जल, स्कूल)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = villageName,
                        onValueChange = { villageName = it },
                        label = { Text("गांव का नाम") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = budget,
                        onValueChange = { budget = it },
                        label = { Text("अनुमानित बजट") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("विवरण") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        )
    }
}
