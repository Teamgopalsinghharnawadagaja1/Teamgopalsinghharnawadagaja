package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Complaint
import com.example.data.models.ComplaintStatus
import com.example.ui.components.ComplaintCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SaffronOrange
import com.example.viewmodel.MainViewModel

@Composable
fun ComplaintsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val complaints by viewModel.complaints.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val categoryFilter by viewModel.complaintCategoryFilter.collectAsState()
    val isAdminMode by viewModel.isAdminMode.collectAsState()
    val submissionMessage by viewModel.submissionSuccessMessage.collectAsState()

    var showNewComplaintDialog by remember { mutableStateOf(false) }
    var complaintToUpdateStatus by remember { mutableStateOf<Complaint?>(null) }

    // Categories list
    val categories = listOf("सभी", "पानी", "बिजली", "सड़क", "स्वास्थ्य", "शिक्षा", "सफ़ाई", "सिंचाई", "अन्य")

    // Filter logic
    val filteredComplaints = complaints.filter { complaint ->
        val matchesSearch = searchQuery.isBlank() ||
                complaint.id.contains(searchQuery, ignoreCase = true) ||
                complaint.villageName.contains(searchQuery, ignoreCase = true) ||
                complaint.citizenName.contains(searchQuery, ignoreCase = true) ||
                complaint.description.contains(searchQuery, ignoreCase = true)

        val matchesCategory = categoryFilter == "सभी" || complaint.category == categoryFilter

        matchesSearch && matchesCategory
    }

    LaunchedEffect(submissionMessage) {
        submissionMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            viewModel.clearSubmissionMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color(0xFFF8FAFC),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNewComplaintDialog = true },
                containerColor = SaffronOrange,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                elevation = FloatingActionButtonDefaults.elevation(6.dp)
            ) {
                Icon(imageVector = Icons.Default.AddComment, contentDescription = "Add Complaint")
                Spacer(modifier = Modifier.width(8.dp))
                Text("जनसमस्या दर्ज करें", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header Title
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyPrimary)
                    .padding(16.dp)
            ) {
                Text(
                    text = "जनसमस्या निवारण एवं लाइव स्थिति",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "ग्राम पंचायत हरनावदा गजा व झालरापाटन 198 शिकायत निवारण पोर्टल",
                    fontSize = 12.sp,
                    color = GoldAccent
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("शिकायत ID, गांव या आवेदक का नाम खोजें...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = NavyPrimary) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = GoldAccent
                    ),
                    singleLine = true
                )
            }

            // Category Filter Scroll Row
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = categoryFilter == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setComplaintCategoryFilter(cat) },
                        label = {
                            Text(
                                text = cat,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NavyPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // List of Complaints or Empty State
            if (filteredComplaints.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = "No Results",
                            tint = Color.Gray,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "कोई शिकायत नहीं मिली",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF475569)
                        )
                        Text(
                            text = "अन्य श्रेणी चुनें या नीचे बटन से नई समस्या दर्ज करें",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredComplaints) { complaint ->
                        ComplaintCard(
                            complaint = complaint,
                            isAdminMode = isAdminMode,
                            onUpdateStatusClick = { complaintToUpdateStatus = it }
                        )
                    }
                }
            }
        }
    }

    // New Complaint Registration Dialog Modal
    if (showNewComplaintDialog) {
        var category by remember { mutableStateOf("पानी") }
        var villageName by remember { mutableStateOf("हरनावदा गजा") }
        var citizenName by remember { mutableStateOf("") }
        var mobileNumber by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }

        val villageOptions = listOf("हरनावदा गजा", "वरह", "आटकगकला", "कावरदा", "सोनमह", "दुधलिया", "सुवास", "मोगरा")

        AlertDialog(
            onDismissRequest = { showNewComplaintDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        if (citizenName.isNotBlank() && mobileNumber.isNotBlank() && description.isNotBlank()) {
                            viewModel.submitNewComplaint(category, villageName, citizenName, mobileNumber, description)
                            showNewComplaintDialog = false
                        } else {
                            Toast.makeText(context, "कृपया सभी आवश्यक फ़ील्ड भरें", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange)
                ) {
                    Text("दर्ज करें", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewComplaintDialog = false }) {
                    Text("रद्द करें", color = Color.Gray)
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.AddComment, contentDescription = "Add", tint = SaffronOrange)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("जनसमस्या दर्ज करें", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = NavyPrimary)
                }
            },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text("समस्या की श्रेणी (Category):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(listOf("पानी", "बिजली", "सड़क", "स्वास्थ्य", "शिक्षा", "सफ़ाई", "सिंचाई", "अन्य")) { cat ->
                                FilterChip(
                                    selected = category == cat,
                                    onClick = { category = cat },
                                    label = { Text(cat, fontSize = 11.sp) }
                                )
                            }
                        }
                    }

                    item {
                        Text("गांव का नाम (Village):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(villageOptions) { v ->
                                FilterChip(
                                    selected = villageName == v,
                                    onClick = { villageName = v },
                                    label = { Text(v, fontSize = 11.sp) }
                                )
                            }
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = citizenName,
                            onValueChange = { citizenName = it },
                            label = { Text("आपका पूरा नाम *") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = mobileNumber,
                            onValueChange = { mobileNumber = it },
                            label = { Text("मोबाइल नंबर *") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("समस्या का पूरा विवरण *") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )
                    }
                }
            }
        )
    }

    // Admin Status Update Dialog Modal
    complaintToUpdateStatus?.let { complaint ->
        var selectedStatus by remember { mutableStateOf(complaint.status) }
        var remarksText by remember { mutableStateOf(complaint.remarks) }

        AlertDialog(
            onDismissRequest = { complaintToUpdateStatus = null },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateComplaintStatus(complaint.id, selectedStatus, remarksText)
                        complaintToUpdateStatus = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("अद्यतन करें (Update)")
                }
            },
            dismissButton = {
                TextButton(onClick = { complaintToUpdateStatus = null }) {
                    Text("रद्द करें")
                }
            },
            title = {
                Text("शिकायत स्टेटस अद्यतन: ${complaint.id}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("नया स्टेटस चुनें:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    ComplaintStatus.entries.forEach { status ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStatus = status.name }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedStatus == status.name,
                                onClick = { selectedStatus = status.name }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(status.labelHindi, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }

                    OutlinedTextField(
                        value = remarksText,
                        onValueChange = { remarksText = it },
                        label = { Text("टिप्पणी / प्रगति अपडेट") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        )
    }
}
