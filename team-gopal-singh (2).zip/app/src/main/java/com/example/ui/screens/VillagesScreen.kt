package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.HolidayVillage
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.VillageCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyPrimary
import com.example.viewmodel.MainViewModel

@Composable
fun VillagesScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val villages by viewModel.villages.collectAsState()
    var searchVillageQuery by remember { mutableStateOf("") }

    val filteredVillages = villages.filter { v ->
        searchVillageQuery.isBlank() ||
                v.name.contains(searchVillageQuery, ignoreCase = true) ||
                v.panchayat.contains(searchVillageQuery, ignoreCase = true) ||
                v.healthCenter.contains(searchVillageQuery, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyPrimary)
                .padding(16.dp)
        ) {
            Text(
                text = "ग्राम पंचायत एवं गांव विवरण",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "हरनावदा गजा व झालरापाटन 198 क्षेत्र के गाँव (स्थानीय सर्वेक्षण / सत्यापन प्रक्रियाधीन)",
                fontSize = 12.sp,
                color = GoldAccent
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar
            OutlinedTextField(
                value = searchVillageQuery,
                onValueChange = { searchVillageQuery = it },
                placeholder = { Text("गांव या पंचायत का नाम खोजें...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = NavyPrimary) },
                trailingIcon = {
                    if (searchVillageQuery.isNotBlank()) {
                        IconButton(onClick = { searchVillageQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = GoldAccent
                ),
                singleLine = true
            )
        }

        // Summary Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "${villages.size}", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = NavyPrimary)
                    Text(text = "सूचीबद्ध गाँव", fontSize = 11.sp, color = Color.Gray)
                }
                VerticalDivider(modifier = Modifier.height(24.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "पिड़ावा/सुनेल", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = NavyPrimary)
                    Text(text = "तहसील (LGD: 1295)", fontSize = 11.sp, color = Color.Gray)
                }
                VerticalDivider(modifier = Modifier.height(24.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "AC-198", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = NavyPrimary)
                    Text(text = "सत्यापन लंबित", fontSize = 11.sp, color = Color(0xFFD97706))
                }
            }
        }

        // Village Cards List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredVillages) { village ->
                VillageCard(village = village)
            }
        }
    }
}
