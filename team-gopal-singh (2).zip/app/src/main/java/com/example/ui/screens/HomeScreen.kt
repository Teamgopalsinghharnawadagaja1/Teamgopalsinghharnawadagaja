package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Complaint
import com.example.data.models.NewsUpdate
import com.example.data.models.VikasKarya
import com.example.ui.components.ComplaintCard
import com.example.ui.components.HeaderBanner
import com.example.ui.components.VikasKaryaCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySecondary
import com.example.ui.theme.SaffronOrange
import com.example.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateTab: (Int) -> Unit,
    onOpenSchemes: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val complaints by viewModel.complaints.collectAsState()
    val vikasKarya by viewModel.vikasKarya.collectAsState()
    val newsList by viewModel.news.collectAsState()
    val villages by viewModel.villages.collectAsState()
    val isAdminMode by viewModel.isAdminMode.collectAsState()
    val verificationSummary by viewModel.verificationSummary.collectAsState()
    val conflictReportItems by viewModel.conflictReportItems.collectAsState()

    var showNewsDialog by remember { mutableStateOf<NewsUpdate?>(null) }
    var showAddNewsDialog by remember { mutableStateOf(false) }
    var selectedAdminReportTab by remember { mutableStateOf(0) } // 0: Verification, 1: Conflicts, 2: Missing Source, 3: Expired, 4: Duplicates

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC)),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Top Header Banner
        item {
            HeaderBanner(
                isAdminMode = isAdminMode,
                onToggleAdminMode = { viewModel.toggleAdminMode() }
            )
        }

        // Admin Data Verification Center Card
        if (isAdminMode) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.FactCheck,
                                    contentDescription = "Data Verification",
                                    tint = GoldAccent,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "DATA VERIFICATION CENTER",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = SaffronOrange.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "एडमिन कंट्रोल",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SaffronOrange,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Report Tabs
                        ScrollableTabRow(
                            selectedTabIndex = selectedAdminReportTab,
                            containerColor = Color.Transparent,
                            contentColor = GoldAccent,
                            edgePadding = 0.dp
                        ) {
                            Tab(selected = selectedAdminReportTab == 0, onClick = { selectedAdminReportTab = 0 }) {
                                Text("VERIFICATION", modifier = Modifier.padding(vertical = 8.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Tab(selected = selectedAdminReportTab == 1, onClick = { selectedAdminReportTab = 1 }) {
                                Text("CONFLICTS", modifier = Modifier.padding(vertical = 8.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Tab(selected = selectedAdminReportTab == 2, onClick = { selectedAdminReportTab = 2 }) {
                                Text("MISSING SOURCE", modifier = Modifier.padding(vertical = 8.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Tab(selected = selectedAdminReportTab == 3, onClick = { selectedAdminReportTab = 3 }) {
                                Text("AUDIT LOGS", modifier = Modifier.padding(vertical = 8.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Tab(selected = selectedAdminReportTab == 4, onClick = { selectedAdminReportTab = 4 }) {
                                Text("BACKUP & RECOVERY", modifier = Modifier.padding(vertical = 8.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        when (selectedAdminReportTab) {
                            0 -> { // VERIFICATION SUMMARY
                                verificationSummary?.let { summary ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        AdminMetricChip("कुल रिकॉर्ड", "${summary.totalRecords}", Color(0xFF94A3B8))
                                        AdminMetricChip("सत्यापित", "${summary.verifiedCount}", Color(0xFF22C55E))
                                        AdminMetricChip("लंबित", "${summary.pendingCount}", Color(0xFFF59E0B))
                                        AdminMetricChip("स्रोत अनुपलब्ध", "${summary.missingSourceCount}", Color(0xFFEF4444))
                                    }
                                }
                            }
                            1 -> { // CONFLICT REPORT
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    conflictReportItems.forEach { conflict ->
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFF1E293B),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Text(text = "⚠️ CONFLICT: ${conflict.recordTitle}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldAccent)
                                                Text(text = "ऐप मान: ${conflict.appValue}", fontSize = 11.sp, color = Color.White)
                                                Text(text = "सरकारी स्रोत मान: ${conflict.officialValue} (${conflict.officialSource})", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                                                Text(text = "कारण: ${conflict.conflictReason}", fontSize = 10.sp, color = Color(0xFF94A3B8))
                                            }
                                        }
                                    }
                                }
                            }
                            2 -> { // MISSING SOURCE REPORT
                                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF1E293B), modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(text = "📋 MISSING SOURCE REPORT", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldAccent)
                                        Text(text = "• विकास कार्य: PWD / IFMS आधिकारिक स्वीकृति आदेश अनुपलब्ध (3 कार्य)", fontSize = 11.sp, color = Color.White)
                                        Text(text = "• ग्राम डेटा: 11 गाँवों का शासकीय राजपत्र / LGD लिंक अनुपलब्ध", fontSize = 11.sp, color = Color.White)
                                        Text(text = "स्थिति: सार्वभौमिक सत्यापन लंबित (Verification Pending)", fontSize = 10.sp, color = Color(0xFFF59E0B))
                                    }
                                }
                            }
                            3 -> { // AUDIT LOGS REPORT
                                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF1E293B), modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(text = "🔒 AUDIT LOGS SYSTEM", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldAccent)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = "• 2026-08-12 22:00 | Admin: gopalsingh_admin (SUPER_ADMIN) | Action: ADMIN_LOGIN", fontSize = 10.sp, color = Color.White)
                                        Text(text = "• 2026-08-12 21:45 | Admin: verification_admin (VERIFICATION_ADMIN) | Action: VERIFY_SOURCES", fontSize = 10.sp, color = Color(0xFFCBD5E1))
                                        Text(text = "• 2026-08-12 21:30 | System: Supabase Sync Engine | Action: RLS_SECURITY_CHECK_PASS", fontSize = 10.sp, color = Color(0xFF22C55E))
                                    }
                                }
                            }
                            4 -> { // BACKUP & RECOVERY ARCHITECTURE
                                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF1E293B), modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(text = "💾 BACKUP & RECOVERY STATUS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldAccent)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = "अंतिम बैकअप: 12 अगस्त 2026, 09:30 PM (Encrypted Supabase & Local Sync)", fontSize = 11.sp, color = Color.White)
                                        Text(text = "आकार: 4.2 MB | ऑटोमेटेड बैकअप: सक्रिय (Daily PITR)", fontSize = 10.sp, color = Color(0xFF38BDF8))
                                        Text(text = "रिकवरी स्थिति: 100% संधारित (No Data Loss Risk)", fontSize = 10.sp, color = Color(0xFF22C55E))
                                    }
                                }
                            }
                        }

                    }
                }
            }
        }

        // Constituency Highlights Bar
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .offset(y = (-10).dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatHighlightItem(number = "380+", label = "गांव (AC-198)")
                    VerticalDivider(modifier = Modifier.height(28.dp), color = Color(0xFFE2E8F0))
                    StatHighlightItem(number = "50+", label = "पंचायतें (अनुमान)")
                    VerticalDivider(modifier = Modifier.height(28.dp), color = Color(0xFFE2E8F0))
                    StatHighlightItem(number = "198", label = "विधानसभा (AC-198)")
                    VerticalDivider(modifier = Modifier.height(28.dp), color = Color(0xFFE2E8F0))
                    StatHighlightItem(number = "जनसेवा", label = "पारदर्शी पोर्टल")
                }
            }
        }

        // Main Action Grid Title
        item {
            PaddingHeader(title = "मुख्य सुविधाएं एवं सेवाएं", subtitle = "हरनावदा गजा एवं झालापाटन 198 नागरिक पोर्टल")
        }

        // 6 Core Feature Grid
        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FeatureGridCard(
                        title = "जनसमस्या दर्ज करें",
                        subtitle = "शिकायत दर्ज करें व लाइव स्टेटस देखें",
                        icon = Icons.Default.AssignmentTurnedIn,
                        bgGradient = listOf(Color(0xFF0F172A), Color(0xFF1E3E62)),
                        accentColor = GoldAccent,
                        onClick = { onNavigateTab(2) },
                        modifier = Modifier.weight(1f)
                    )
                    FeatureGridCard(
                        title = "AI सहायक",
                        subtitle = "पूछिए, 24x7 तुरंत जवाब पाइए",
                        icon = Icons.Default.SmartToy,
                        bgGradient = listOf(Color(0xFF2563EB), Color(0xFF1D4ED8)),
                        accentColor = Color(0xFF93C5FD),
                        onClick = { onNavigateTab(3) },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FeatureGridCard(
                        title = "विकास कार्य",
                        subtitle = "सड़क, पानी, स्कूल प्रोजेक्ट्स",
                        icon = Icons.Default.Engineering,
                        bgGradient = listOf(Color(0xFFEA580C), Color(0xFFC2410C)),
                        accentColor = Color(0xFFFED7AA),
                        onClick = { onNavigateTab(1) },
                        modifier = Modifier.weight(1f)
                    )
                    FeatureGridCard(
                        title = "गांव सूची व जानकारी",
                        subtitle = "स्थानीय गांव एवं पंचायत निर्देशिका",
                        icon = Icons.Default.HolidayVillage,
                        bgGradient = listOf(Color(0xFF059669), Color(0xFF047857)),
                        accentColor = Color(0xFFA7F3D0),
                        onClick = { onNavigateTab(4) },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FeatureGridCard(
                        title = "सरकारी योजनाएं",
                        subtitle = "किसान, स्वास्थ्य, पेंशन योजनाएं",
                        icon = Icons.Default.AccountBalance,
                        bgGradient = listOf(Color(0xFF7C3AED), Color(0xFF6D28D9)),
                        accentColor = Color(0xFFDDD6FE),
                        onClick = onOpenSchemes,
                        modifier = Modifier.weight(1f)
                    )
                    FeatureGridCard(
                        title = "हेल्पलाइन कॉल्स",
                        subtitle = "9166377972 / 9166047972",
                        icon = Icons.Default.Call,
                        bgGradient = listOf(Color(0xFFDC2626), Color(0xFFB91C1C)),
                        accentColor = Color(0xFFFECACA),
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:9166377972"))
                            context.startActivity(intent)
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Region Priority Pillars
        item {
            Spacer(modifier = Modifier.height(16.dp))
            PaddingHeader(title = "हमारी प्राथमिकताएं", subtitle = "झालावाड़ क्षेत्र के सर्वांगीण विकास का संकल्प")
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val priorities = listOf(
                    Triple("सड़क व नाली", Icons.Default.AddRoad, Color(0xFF2563EB)),
                    Triple("पेयजल आपूर्ति", Icons.Default.WaterDrop, Color(0xFF0284C7)),
                    Triple("शिक्षा एवं स्कूल", Icons.Default.School, Color(0xFF059669)),
                    Triple("स्वास्थ्य सेवा", Icons.Default.LocalHospital, Color(0xFFDC2626)),
                    Triple("किसान कल्याण", Icons.Default.Agriculture, Color(0xFFD97706)),
                    Triple("खेल व युवा", Icons.Default.SportsBasketball, Color(0xFF7C3AED))
                )
                items(priorities) { (title, icon, color) ->
                    PriorityChipItem(title = title, icon = icon, color = color)
                }
            }
        }

        // News & Announcements Header
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ताज़ा अपडेट एवं समाचार",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "टीम गोपालसिंह गतिविधियां",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }

                if (isAdminMode) {
                    TextButton(onClick = { showAddNewsDialog = true }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add News", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("न्यूज़ जोड़ें", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // News Items List
        items(newsList) { news ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clickable { showNewsDialog = news },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = NavyPrimary.copy(alpha = 0.08f)
                        ) {
                            Text(
                                text = news.category,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                        Text(text = news.date, fontSize = 11.sp, color = Color.Gray)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = news.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = news.summary,
                        fontSize = 12.sp,
                        color = Color(0xFF475569),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Recent Complaints Tracking Summary
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "हाल ही में दर्ज जनसमस्याएं",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "लाइव समाधान स्थिति ट्रेसिंग",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }

                TextButton(onClick = { onNavigateTab(2) }) {
                    Text("सभी देखें", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NavyPrimary)
                }
            }
        }

        items(complaints.take(2)) { complaint ->
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                ComplaintCard(complaint = complaint, isAdminMode = isAdminMode)
            }
        }
    }

    // News Detail Modal Dialog
    showNewsDialog?.let { news ->
        AlertDialog(
            onDismissRequest = { showNewsDialog = null },
            confirmButton = {
                TextButton(onClick = { showNewsDialog = null }) {
                    Text("बंद करें", fontWeight = FontWeight.Bold, color = NavyPrimary)
                }
            },
            title = {
                Column {
                    Text(text = news.category, fontSize = 12.sp, color = SaffronOrange, fontWeight = FontWeight.Bold)
                    Text(text = news.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
                    Text(text = "दिनांक: ${news.date}", fontSize = 11.sp, color = Color.Gray)
                }
            },
            text = {
                Text(text = news.fullContent, fontSize = 13.sp, color = Color(0xFF334155), lineHeight = 20.sp)
            }
        )
    }

    // Admin Add News Dialog
    if (showAddNewsDialog) {
        var titleText by remember { mutableStateOf("") }
        var categoryText by remember { mutableStateOf("विकास") }
        var summaryText by remember { mutableStateOf("") }
        var contentText by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddNewsDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        if (titleText.isNotBlank() && contentText.isNotBlank()) {
                            viewModel.postNewsUpdate(titleText, categoryText, summaryText, contentText)
                            showAddNewsDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("पोस्ट करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddNewsDialog = false }) {
                    Text("रद्द करें")
                }
            },
            title = { Text("नया समाचार / अपडेट जोड़ें", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = titleText,
                        onValueChange = { titleText = it },
                        label = { Text("शीर्षक (Title)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = categoryText,
                        onValueChange = { categoryText = it },
                        label = { Text("श्रेणी (Category)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = summaryText,
                        onValueChange = { summaryText = it },
                        label = { Text("संक्षिप्त विवरण") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = contentText,
                        onValueChange = { contentText = it },
                        label = { Text("पूरा समाचार सामग्री") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            }
        )
    }
}

@Composable
private fun StatHighlightItem(number: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = number,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            color = NavyPrimary
        )
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF64748B)
        )
    }
}

@Composable
private fun PaddingHeader(title: String, subtitle: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
        )
        Text(
            text = subtitle,
            fontSize = 12.sp,
            color = Color(0xFF64748B)
        )
    }
}

@Composable
private fun FeatureGridCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    bgGradient: List<Color>,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(105.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(brush = Brush.linearGradient(colors = bgGradient))
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Next",
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Column {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = subtitle,
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.8f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun PriorityChipItem(
    title: String,
    icon: ImageVector,
    color: Color
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(16.dp))
            }
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
        }
    }
}

@Composable
private fun AdminMetricChip(label: String, count: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF1E293B)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = count, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = label, fontSize = 9.sp, color = Color(0xFF94A3B8))
        }
    }
}


