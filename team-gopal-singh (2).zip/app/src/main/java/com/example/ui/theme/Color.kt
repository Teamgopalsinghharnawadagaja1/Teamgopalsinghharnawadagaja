package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF0B192C)
val NavySecondary = Color(0xFF1E3E62)
val GoldAccent = Color(0xFFD4AF37)
val SaffronOrange = Color(0xFFEA580C)
val CrimsonRed = Color(0xFFDC2626)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)

val DarkBackground = Color(0xFF0B192C)
val DarkSurface = Color(0xFF1E293B)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)

