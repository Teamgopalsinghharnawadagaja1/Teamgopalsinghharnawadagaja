package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.ui.components.BottomNavigationBar
import com.example.ui.components.GovtSchemesSheet
import com.example.ui.screens.*
import com.example.ui.theme.TeamGopalSinghTheme
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val mainViewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TeamGopalSinghTheme {
                val selectedTab by mainViewModel.selectedTab.collectAsState()
                var showGovtSchemesSheet by remember { mutableStateOf(false) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        BottomNavigationBar(
                            selectedTab = selectedTab,
                            onTabSelected = { mainViewModel.setSelectedTab(it) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        Crossfade(targetState = selectedTab, label = "ScreenTransition") { tabIndex ->
                            when (tabIndex) {
                                0 -> HomeScreen(
                                    viewModel = mainViewModel,
                                    onNavigateTab = { mainViewModel.setSelectedTab(it) },
                                    onOpenSchemes = { showGovtSchemesSheet = true }
                                )
                                1 -> VikasKaryaScreen(
                                    viewModel = mainViewModel
                                )
                                2 -> ComplaintsScreen(
                                    viewModel = mainViewModel
                                )
                                3 -> AiSahayakScreen(
                                    viewModel = mainViewModel
                                )
                                4 -> VillagesScreen(
                                    viewModel = mainViewModel
                                )
                            }
                        }

                        if (showGovtSchemesSheet) {
                            GovtSchemesSheet(
                                schemes = mainViewModel.schemes,
                                onDismiss = { showGovtSchemesSheet = false }
                            )
                        }
                    }
                }
            }
        }
    }
}

