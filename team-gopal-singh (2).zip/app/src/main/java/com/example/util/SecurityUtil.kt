package com.example.util

import com.example.data.models.FileValidationResult

object FileSecurityUtil {
    private val ALLOWED_MIME_TYPES = setOf("image/jpeg", "image/png", "image/webp", "application/pdf")
    private val ALLOWED_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "pdf")
    private const val MAX_PHOTO_SIZE_BYTES = 5 * 1024 * 1024L // 5 MB
    private const val MAX_DOC_SIZE_BYTES = 10 * 1024 * 1024L // 10 MB

    fun validateAndSanitizeFile(
        fileName: String,
        mimeType: String,
        fileSizeBytes: Long
    ): FileValidationResult {
        // 1. Sanitize file name (remove path traversal, non-alphanumeric except safe chars)
        val cleanName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            .replace("..", "_")
        
        val ext = cleanName.substringAfterLast('.', "").lowercase()
        if (ext.isBlank() || ext !in ALLOWED_EXTENSIONS) {
            return FileValidationResult(
                isValid = false,
                sanitizedFileName = cleanName,
                errorMessage = "अमान्य फ़ाइल एक्सटेंशन ($ext)। केवल JPG, PNG, WEBP, PDF समर्थित हैं।"
            )
        }

        // 2. Validate MIME type
        if (mimeType.lowercase() !in ALLOWED_MIME_TYPES) {
            return FileValidationResult(
                isValid = false,
                sanitizedFileName = cleanName,
                errorMessage = "अमान्य फ़ाइल प्रकार ($mimeType)। असुरक्षित फ़ाइल अपलोड प्रतिबंधित है।"
            )
        }

        // 3. File size limit
        val maxSize = if (ext == "pdf") MAX_DOC_SIZE_BYTES else MAX_PHOTO_SIZE_BYTES
        if (fileSizeBytes > maxSize) {
            val maxMb = maxSize / (1024 * 1024)
            return FileValidationResult(
                isValid = false,
                sanitizedFileName = cleanName,
                errorMessage = "फ़ाइल का आकार अत्यधिक है (${fileSizeBytes / (1024 * 1024)}MB)। अधिकतम सीमा ${maxMb}MB है।"
            )
        }

        return FileValidationResult(
            isValid = true,
            sanitizedFileName = cleanName,
            errorMessage = null
        )
    }
}

object InputSanitizer {
    fun sanitizeTextInput(input: String): String {
        return input
            .replace(Regex("<[^>]*>"), "") // Remove HTML tags (XSS Prevention)
            .replace("'", "''") // SQL Injection escape
            .trim()
    }

    fun isSafeUrl(url: String): Boolean {
        if (!url.startsWith("https://")) return false
        val safeDomains = listOf("gov.in", "rajasthan.gov.in", "myscheme.gov.in", "lgdirectory.gov.in", "eci.gov.in")
        return safeDomains.any { url.contains(it) } || url.contains("teamgopalsingh")
    }
}

object SupabaseRlsDocumentation {
    fun getSupabaseSqlSchema(): String {
        return """
            -- ============================================================
            -- SUPABASE PRODUCTION DATABASE SCHEMA & RLS POLICIES
            -- Team GopalSingh – Harnavada Gaja (AC-198 Jhalrapatan)
            -- ============================================================

            -- 1. Enable Row Level Security on all exposed tables
            ALTER TABLE public.complaints ENABLE ROW LEVEL SECURITY;
            ALTER TABLE public.vikas_karya ENABLE ROW LEVEL SECURITY;
            ALTER TABLE public.villages ENABLE ROW LEVEL SECURITY;
            ALTER TABLE public.news_updates ENABLE ROW LEVEL SECURITY;
            ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

            -- 2. PUBLIC READ POLICIES (Only public_visible = true AND is_deleted = false)
            CREATE POLICY "Public Read Vikas Karya" ON public.vikas_karya
                FOR SELECT USING (is_deleted = false AND status IS NOT NULL);

            CREATE POLICY "Public Read Villages" ON public.villages
                FOR SELECT USING (is_deleted = false);

            CREATE POLICY "Public Read News" ON public.news_updates
                FOR SELECT USING (is_deleted = false);

            -- 3. COMPLAINTS PRIVACY POLICY (User can only read/create own complaints)
            CREATE POLICY "Users insert own complaint" ON public.complaints
                FOR INSERT WITH CHECK (auth.uid() IS NOT NULL OR is_internal_reference = true);

            CREATE POLICY "Users select own complaint" ON public.complaints
                FOR SELECT USING (auth.uid() = user_id OR auth.jwt() ->> 'role' IN ('super_admin', 'complaint_admin'));

            -- 4. ADMIN RBAC POLICIES (Strict role enforcement)
            CREATE POLICY "Admin full management" ON public.vikas_karya
                FOR ALL USING (auth.jwt() ->> 'role' IN ('super_admin', 'development_admin'));

            CREATE POLICY "Complaint Admin management" ON public.complaints
                FOR ALL USING (auth.jwt() ->> 'role' IN ('super_admin', 'complaint_admin'));

            CREATE POLICY "Audit logs read/write" ON public.audit_logs
                FOR ALL USING (auth.jwt() ->> 'role' IN ('super_admin', 'verification_admin'));

            -- 5. AUDIT TRIGGER FOR DATA INTEGRITY
            CREATE OR REPLACE FUNCTION log_admin_action()
            RETURNS TRIGGER AS $$
            BEGIN
                INSERT INTO public.audit_logs (admin_id, role, action, table_name, record_id, old_value, new_value, timestamp)
                VALUES (
                    auth.uid()::text,
                    auth.jwt() ->> 'role',
                    TG_OP,
                    TG_TABLE_NAME,
                    NEW.id::text,
                    row_to_json(OLD)::text,
                    row_to_json(NEW)::text,
                    NOW()
                );
                RETURN NEW;
            END;
            $$ LANGUAGE plpgsql SECURITY DEFINER;
        """.trimIndent()
    }
}
