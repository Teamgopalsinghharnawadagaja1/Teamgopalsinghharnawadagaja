package com.example.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class VerificationStatus(val labelHindi: String, val badgeColorHex: Long) {
    VERIFIED("सत्यापित स्रोत", 0xFF16A34A),
    VERIFICATION_PENDING("सत्यापन लंबित", 0xFFD97706),
    UNVERIFIED_LOCAL_SURVEY("स्थानीय सर्वेक्षण", 0xFF2563EB),
    MISSING_SOURCE("स्रोत अनुपलब्ध", 0xFFDC2626)
}

enum class AdminRole(val roleKey: String, val labelHindi: String) {
    SUPER_ADMIN("super_admin", "सुपर एडमिन (पूर्ण अधिकार)"),
    CONTENT_ADMIN("content_admin", "कंटेंट एडमिन (समाचार/सूचनाएँ)"),
    DEVELOPMENT_ADMIN("development_admin", "विकास कार्य एडमिन"),
    COMPLAINT_ADMIN("complaint_admin", "जनसमस्या निवारण एडमिन"),
    ELECTION_DATA_ADMIN("election_data_admin", "चुनाव डेटा एडमिन (एग्रीगेट डेटा)"),
    VERIFICATION_ADMIN("verification_admin", "सत्यापन एवं ऑडिट एडमिन")
}

data class AdminUser(
    val username: String,
    val role: AdminRole,
    val sessionToken: String,
    val isMfaVerified: Boolean = true,
    val lastLoginTimestamp: String = "2026-08-12 10:00 AM"
)

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val admin_id: String,
    val role: String,
    val action: String,
    val table_name: String,
    val record_id: String,
    val old_value: String,
    val new_value: String,
    val timestamp: String,
    val metadata: String = "privacy_safe_device",
    val notes: String = ""
)

enum class ComplaintStatus(val labelHindi: String, val colorHex: Long) {
    RECEIVED("शिकायत दर्ज", 0xFF0284C7),
    INVESTIGATING("जाँच शुरू", 0xFFD97706),
    DEPT_SENT("संबंधित विभाग को भेजी गई", 0xFF7C3AED),
    IN_PROGRESS("कार्रवाई जारी", 0xFF2563EB),
    RESOLVED("समाधान हो गया", 0xFF16A34A),
    CLOSED("बंद", 0xFF475569)
}

@Entity(tableName = "complaints")
data class Complaint(
    @PrimaryKey val id: String, // e.g. JHL-198-2026-0001 (Internal Reference)
    val category: String, // पानी, सड़क, बिजली, शिक्षा, स्वास्थ्य, सफ़ाई, सिंचाई, अन्य
    val villageName: String,
    val citizenName: String,
    val mobileNumber: String,
    val description: String,
    val dateFiled: String,
    val status: String, // Matches ComplaintStatus enum name
    val lastUpdatedDate: String,
    val location: String = "हरनावदा गजा",
    val remarks: String = "आंतरिक पंजीयन। यह शासकीय शिकायत संख्या नहीं है।",
    val isInternalReference: Boolean = true,
    val govtComplaintNumber: String = "आधिकारिक जानकारी उपलब्ध नहीं है",
    val created_at: String = "2026-08-12",
    val updated_at: String = "2026-08-12",
    val is_deleted: Boolean = false,
    // Verification Metadata Architecture
    val source_url: String = "आंतरिक नागरिक पोर्टल",
    val source_name: String = "टीम गोपालसिंह नागरिक पंजीयन",
    val source_date: String = "2026",
    val verification_status: String = VerificationStatus.UNVERIFIED_LOCAL_SURVEY.name,
    val verified_at: String = "2026-08-12",
    val last_verified_at: String = "2026-08-12",
    val verification_expiry: String = "2026-12-31",
    val data_version: String = "v1.0",
    val verified_by: String = "आंतरिक टीम",
    val notes: String = "नागरिक द्वारा प्रस्तुत आंतरिक संदर्भ आवेदन"
)

enum class VikasStatus(val labelHindi: String) {
    PLANNED("स्वीकृत"),
    IN_PROGRESS("निर्माणाधीन"),
    COMPLETED("पूर्ण")
}

@Entity(tableName = "vikas_karya")
data class VikasKarya(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String, // सड़क, जल जीवन, शिक्षा, स्वास्थ्य, कृषि, विद्युत
    val villageName: String,
    val estimatedBudget: String,
    val status: String, // PLANNED, IN_PROGRESS, COMPLETED
    val progressPercentage: Int, // 0 to 100
    val description: String,
    val startDate: String,
    val targetCompletionDate: String,
    val created_at: String = "2026-08-12",
    val updated_at: String = "2026-08-12",
    val is_deleted: Boolean = false,
    // Verification Metadata Architecture
    val source_url: String = "आधिकारिक दस्तावेज उपलब्ध नहीं है",
    val source_name: String = "स्थानीय नागरिक ट्रैकिंग",
    val source_date: String = "2026",
    val verification_status: String = VerificationStatus.VERIFICATION_PENDING.name,
    val verified_at: String = "2026-08-12",
    val last_verified_at: String = "2026-08-12",
    val verification_expiry: String = "2026-12-31",
    val data_version: String = "v1.0",
    val verified_by: String = "स्थानीय दल",
    val notes: String = "शासकीय वित्तीय स्वीकृति दस्तावेज हेतु सत्यापन लंबित"
)

@Entity(tableName = "villages")
data class Village(
    @PrimaryKey val id: Int,
    val name: String,
    val panchayat: String,
    val tehsil: String = "पिड़ावा",
    val district: String = "झालावाड़",
    val assemblyConstituency: String = "झालरापाटन 198",
    val population: Int,
    val votersCount: Int,
    val schoolsCount: Int,
    val anganwadiCount: Int,
    val healthCenter: String,
    val keyRepresentative: String = "टीम प्रतिनिधि",
    val contactPhone: String = "9166377972",
    val created_at: String = "2026-08-12",
    val updated_at: String = "2026-08-12",
    val is_deleted: Boolean = false,
    // Verification Metadata Architecture
    val source_url: String = "https://lgdirectory.gov.in",
    val source_name: String = "LGD Portal / स्थानीय सर्वेक्षण",
    val source_date: String = "2024-2026",
    val verification_status: String = VerificationStatus.UNVERIFIED_LOCAL_SURVEY.name,
    val verified_at: String = "2026-08-12",
    val last_verified_at: String = "2026-08-12",
    val verification_expiry: String = "2026-12-31",
    val data_version: String = "v1.0",
    val verified_by: String = "स्थानीय प्रतिनिधि सर्वेक्षण",
    val notes: String = "जनसंख्या व मतदाता आंकड़े स्थानीय अनुमान पर आधारित हैं"
)

@Entity(tableName = "news_updates")
data class NewsUpdate(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val date: String,
    val category: String, // विकास, जनसंवाद, समारोह, आवश्यक सूचना
    val summary: String,
    val fullContent: String,
    val isPinned: Boolean = false,
    val created_at: String = "2026-08-12",
    val updated_at: String = "2026-08-12",
    val is_deleted: Boolean = false,
    // Verification Metadata Architecture
    val source_url: String = "टीम प्रेस विज्ञप्ति",
    val source_name: String = "टीम गोपालसिंह जनसंपर्क",
    val source_date: String = "2026",
    val verification_status: String = VerificationStatus.VERIFIED.name,
    val verified_at: String = "2026-08-12",
    val last_verified_at: String = "2026-08-12",
    val verification_expiry: String = "2026-12-31",
    val data_version: String = "v1.0",
    val verified_by: String = "प्रेस टीम",
    val notes: String = "आधिकारिक जनसंपर्क वक्तव्य"
)

data class GovtScheme(
    val id: String,
    val name: String,
    val category: String,
    val benefitText: String,
    val eligibility: String,
    val helpline: String,
    val source_url: String = "https://myscheme.gov.in",
    val source_name: String = "myScheme / संबंधित मंत्रालय पोर्टल",
    val verification_status: String = VerificationStatus.VERIFIED.name
)

data class VerificationReportSummary(
    val totalRecords: Int,
    val verifiedCount: Int,
    val pendingCount: Int,
    val unverifiedSurveyCount: Int,
    val missingSourceCount: Int,
    val duplicateCount: Int,
    val conflictsCount: Int
)

data class DataConflictItem(
    val entityType: String,
    val recordTitle: String,
    val appValue: String,
    val officialValue: String,
    val officialSource: String,
    val conflictReason: String
)

data class BackupStatusInfo(
    val lastBackupTimestamp: String = "12 अगस्त 2026, 09:30 PM",
    val backupStatus: String = "सफल (Encrypted Supabase & Local Room Sync)",
    val backupSizeMb: Double = 4.2,
    val autoBackupEnabled: Boolean = true,
    val recoveryPointInfo: String = "Daily Point-in-time Recovery (PITR Active)"
)

data class FileValidationResult(
    val isValid: Boolean,
    val sanitizedFileName: String,
    val errorMessage: String? = null
)

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "USER" or "AI"
    val text: String,
    val timestamp: String = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())
)


