package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.models.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class AppRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val complaintDao = db.complaintDao()
    private val vikasKaryaDao = db.vikasKaryaDao()
    private val villageDao = db.villageDao()
    private val newsDao = db.newsDao()
    private val auditLogDao = db.auditLogDao()

    val allComplaints: Flow<List<Complaint>> = complaintDao.getAllComplaints()
    val allVikasKarya: Flow<List<VikasKarya>> = vikasKaryaDao.getAllVikasKarya()
    val allVillages: Flow<List<Village>> = villageDao.getAllVillages()
    val allNews: Flow<List<NewsUpdate>> = newsDao.getAllNews()
    val allAuditLogs: Flow<List<AuditLog>> = auditLogDao.getAllAuditLogs()

    suspend fun recordAuditLog(
        adminId: String,
        role: String,
        action: String,
        tableName: String,
        recordId: String,
        oldValue: String,
        newValue: String,
        notes: String = ""
    ) {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        val log = AuditLog(
            admin_id = adminId,
            role = role,
            action = action,
            table_name = tableName,
            record_id = recordId,
            old_value = oldValue,
            new_value = newValue,
            timestamp = today,
            metadata = "privacy_safe_device_id",
            notes = notes
        )
        auditLogDao.insertAuditLog(log)
    }

    suspend fun getComplaintById(id: String): Complaint? = complaintDao.getComplaintById(id)

    suspend fun addComplaint(
        category: String,
        villageName: String,
        citizenName: String,
        mobileNumber: String,
        description: String
    ): String {
        val count = (allComplaints.first().size + 1).toString().padStart(4, '0')
        val id = "JHL-198-2026-$count"
        val today = java.text.SimpleDateFormat("dd अप्रैल 2026", java.util.Locale("hi", "IN")).format(java.util.Date())
        
        val complaint = Complaint(
            id = id,
            category = category,
            villageName = villageName,
            citizenName = citizenName,
            mobileNumber = mobileNumber,
            description = description,
            dateFiled = today,
            status = ComplaintStatus.RECEIVED.name,
            lastUpdatedDate = today,
            remarks = "आपकी जनसमस्या पंजीकृत कर ली गई है। टीम गोपालसिंह द्वारा कार्यवाही हेतु संबंधित विभाग को प्रेषित की जा रही है।"
        )
        complaintDao.insertComplaint(complaint)
        return id
    }

    suspend fun updateComplaintStatus(
        id: String,
        newStatus: String,
        remarks: String,
        adminUser: AdminUser? = null
    ) {
        val today = java.text.SimpleDateFormat("dd अप्रैल 2026", java.util.Locale("hi", "IN")).format(java.util.Date())
        val oldComplaint = complaintDao.getComplaintById(id)
        val oldStatus = oldComplaint?.status ?: "UNKNOWN"
        complaintDao.updateComplaintStatus(id, newStatus, remarks, today)

        if (adminUser != null) {
            recordAuditLog(
                adminId = adminUser.username,
                role = adminUser.role.roleKey,
                action = "UPDATE_STATUS",
                tableName = "complaints",
                recordId = id,
                oldValue = oldStatus,
                newValue = "$newStatus | $remarks",
                notes = "Complaint status updated by admin"
            )
        }
    }

    suspend fun addVikasKarya(vikasKarya: VikasKarya, adminUser: AdminUser? = null) {
        vikasKaryaDao.insertVikasKarya(vikasKarya)
        if (adminUser != null) {
            recordAuditLog(
                adminId = adminUser.username,
                role = adminUser.role.roleKey,
                action = "INSERT_VIKAS",
                tableName = "vikas_karya",
                recordId = vikasKarya.title,
                oldValue = "NONE",
                newValue = "Budget: ${vikasKarya.estimatedBudget}",
                notes = "New Vikas Karya added"
            )
        }
    }

    suspend fun addNews(news: NewsUpdate, adminUser: AdminUser? = null) {
        newsDao.insertNews(news)
        if (adminUser != null) {
            recordAuditLog(
                adminId = adminUser.username,
                role = adminUser.role.roleKey,
                action = "INSERT_NEWS",
                tableName = "news_updates",
                recordId = news.title,
                oldValue = "NONE",
                newValue = news.category,
                notes = "News update added"
            )
        }
    }

    fun getBackupStatusInfo(): BackupStatusInfo {
        return BackupStatusInfo()
    }


    suspend fun seedInitialDataIfNeeded() {
        val villagesList = villageDao.getAllVillages().first()
        if (villagesList.isEmpty()) {
            val initialVillages = listOf(
                Village(
                    id = 1, name = "हरनावदा गजा", panchayat = "हरनावदा गजा", tehsil = "पिड़ावा", district = "झालावाड़", assemblyConstituency = "झालरापाटन 198",
                    population = 2450, votersCount = 1420, schoolsCount = 3, anganwadiCount = 2, healthCenter = "उप स्वास्थ्य केंद्र हरनावदा गजा",
                    keyRepresentative = "गोपाल सिंह", contactPhone = "9166377972",
                    source_url = "https://lgdirectory.gov.in", source_name = "Local Government Directory (LGD: 105194)", source_date = "2024",
                    verification_status = VerificationStatus.VERIFIED.name, verified_at = "2026-08-12", last_verified_at = "2026-08-12", data_version = "v1.0",
                    verified_by = "LGD Portal Sync", notes = "ग्राम पंचायत हरनावदा गजा LGD Code 39288"
                ),
                Village(
                    id = 2, name = "झालरापाटन ग्रामीण", panchayat = "झालरापाटन", tehsil = "झालरापाटन", district = "झालावाड़", assemblyConstituency = "झालरापाटन 198",
                    population = 5200, votersCount = 3100, schoolsCount = 6, anganwadiCount = 4, healthCenter = "सामुदायिक स्वास्थ्य केंद्र झालरापाटन",
                    keyRepresentative = "मोहनलाल वर्मा", contactPhone = "9166377972",
                    source_url = "https://jhalawar.rajasthan.gov.in", source_name = "Jhalawar District Portal / Local Survey", source_date = "2024",
                    verification_status = VerificationStatus.UNVERIFIED_LOCAL_SURVEY.name, verified_at = "2026-08-12", last_verified_at = "2026-08-12", data_version = "v1.0",
                    verified_by = "नागरिक सर्वेक्षण दल", notes = "जनसंख्या एवं मतदाता आंकड़े स्थानीय अनुमान पर आधारित हैं"
                ),
                Village(
                    id = 3, name = "सुनेल", panchayat = "सुनेल", tehsil = "पिड़ावा", district = "झालावाड़", assemblyConstituency = "झालरापाटन 198",
                    population = 8500, votersCount = 5100, schoolsCount = 8, anganwadiCount = 5, healthCenter = "सामुदायिक स्वास्थ्य केंद्र सुनेल",
                    keyRepresentative = "राजेश गुप्ता", contactPhone = "9166047972",
                    source_url = "https://lgdirectory.gov.in", source_name = "LGD Portal", source_date = "2024",
                    verification_status = VerificationStatus.VERIFIED.name, verified_at = "2026-08-12", last_verified_at = "2026-08-12", data_version = "v1.0",
                    verified_by = "LGD Portal Sync", notes = "कस्बा सुनेल तहसील पिड़ावा/सुनेल"
                ),
                Village(
                    id = 4, name = "बकानी", panchayat = "बकानी", tehsil = "बकानी", district = "झालावाड़", assemblyConstituency = "झालरापाटन 198",
                    population = 9200, votersCount = 5600, schoolsCount = 10, anganwadiCount = 6, healthCenter = "सामुदायिक स्वास्थ्य केंद्र बकानी",
                    keyRepresentative = "सुरेश चंद्र शर्मा", contactPhone = "9166377972",
                    source_url = "https://lgdirectory.gov.in", source_name = "LGD Portal", source_date = "2024",
                    verification_status = VerificationStatus.VERIFIED.name, verified_at = "2026-08-12", last_verified_at = "2026-08-12", data_version = "v1.0",
                    verified_by = "LGD Portal Sync", notes = "तहसील मुख्यालय बकानी"
                ),
                Village(
                    id = 5, name = "वरह", panchayat = "वरह", tehsil = "पिड़ावा", district = "झालावाड़", assemblyConstituency = "झालरापाटन 198",
                    population = 1820, votersCount = 995, schoolsCount = 2, anganwadiCount = 1, healthCenter = "प्राथमिक स्वास्थ्य केंद्र वरह",
                    keyRepresentative = "रामलाल गुर्जर", contactPhone = "9166047972",
                    source_url = "स्थानीय सर्वेक्षण", source_name = "स्थानीय प्रतिनिधि दल", source_date = "2026",
                    verification_status = VerificationStatus.UNVERIFIED_LOCAL_SURVEY.name, verified_at = "2026-08-12", last_verified_at = "2026-08-12", data_version = "v1.0",
                    verified_by = "ग्राम प्रतिनिधि", notes = "शासकीय राजपत्र सत्यापन लंबित"
                )
            )
            villageDao.insertAllVillages(initialVillages)
        }

        val vikasList = vikasKaryaDao.getAllVikasKarya().first()
        if (vikasList.isEmpty()) {
            val initialVikas = listOf(
                VikasKarya(
                    title = "हरनावदा गजा मुख्य सड़क डामरीकरण एवं चौड़ीकरण",
                    category = "सड़क",
                    villageName = "हरनावदा गजा",
                    estimatedBudget = "₹ 42 लाख",
                    status = VikasStatus.IN_PROGRESS.name,
                    progressPercentage = 65,
                    description = "तहसील पिड़ावा से हरनावदा गजा मुख्य मार्ग का उच्च गुणवत्तायुक्त डामरीकरण कार्य।",
                    startDate = "12 मार्च 2026",
                    targetCompletionDate = "25 मई 2026",
                    source_url = "आधिकारिक दस्तावेज उपलब्ध नहीं है",
                    source_name = "टीम गोपालसिंह नागरिक निरीक्षण",
                    source_date = "2026",
                    verification_status = VerificationStatus.VERIFICATION_PENDING.name,
                    verified_at = "2026-08-12",
                    last_verified_at = "2026-08-12",
                    data_version = "v1.0",
                    verified_by = "नागरिक नागरिक निगरानी",
                    notes = "PWD स्वीकृति आदेश संख्या हेतु सत्यापन लंबित"
                ),
                VikasKarya(
                    title = "जल जीवन मिशन के अंतर्गत हर घर नल कनेक्शन (हरनावदा गजा)",
                    category = "जल जीवन",
                    villageName = "हरनावदा गजा",
                    estimatedBudget = "₹ 28 लाख",
                    status = VikasStatus.IN_PROGRESS.name,
                    progressPercentage = 80,
                    description = "उच्च जलाशय टंकी निर्माण एवं शुद्ध पेयजल हेतु पाइपलाइन बिछाने का कार्य।",
                    startDate = "05 जनवरी 2026",
                    targetCompletionDate = "30 अप्रैल 2026",
                    source_url = "आधिकारिक दस्तावेज उपलब्ध नहीं है",
                    source_name = "स्थानीय नागरिक ट्रैकिंग",
                    source_date = "2026",
                    verification_status = VerificationStatus.VERIFICATION_PENDING.name,
                    verified_at = "2026-08-12",
                    last_verified_at = "2026-08-12",
                    data_version = "v1.0",
                    verified_by = "नागरिक दल",
                    notes = "जलदाय विभाग स्वीकृति पत्र हेतु सत्यापन लंबित"
                ),
                VikasKarya(
                    title = "झालरापाटन-सुनेल-पिड़ावा मुख्य मार्ग सुदृढ़ीकरण",
                    category = "सड़क",
                    villageName = "झालरापाटन",
                    estimatedBudget = "₹ 1.85 करोड़",
                    status = VikasStatus.IN_PROGRESS.name,
                    progressPercentage = 45,
                    description = "विधानसभा क्षेत्र 198 के मुख्य आवागमन मार्ग का नवीनीकरण।",
                    startDate = "01 फरवरी 2026",
                    targetCompletionDate = "15 जुलाई 2026",
                    source_url = "आधिकारिक दस्तावेज उपलब्ध नहीं है",
                    source_name = "क्षेत्रीय सर्वेक्षण",
                    source_date = "2026",
                    verification_status = VerificationStatus.VERIFICATION_PENDING.name,
                    verified_at = "2026-08-12",
                    last_verified_at = "2026-08-12",
                    data_version = "v1.0",
                    verified_by = "क्षेत्रीय दल",
                    notes = "सरकारी राजपत्र सत्यापन लंबित"
                )
            )
            vikasKaryaDao.insertAllVikasKarya(initialVikas)
        }

        val newsList = newsDao.getAllNews().first()
        if (newsList.isEmpty()) {
            val initialNews = listOf(
                NewsUpdate(
                    title = "ग्राम हरनावदा गजा में मुख्य सड़क निर्माण कार्य प्रारंभ",
                    date = "12 अप्रैल 2026",
                    category = "विकास",
                    summary = "टीम गोपालसिंह के प्रयासों से मुख्य मार्ग के पुनर्निर्माण का कार्य शुरू हुआ।",
                    fullContent = "झालावाड़ जिले के झालरापाटन विधानसभा क्षेत्र (198) के ग्राम हरनावदा गजा में सड़क निर्माण कार्य की शुरुआत हुई। टीम गोपालसिंह ने गुणवत्ता का जायजा लिया।",
                    isPinned = true,
                    source_url = "टीम प्रेस विज्ञप्ति",
                    source_name = "टीम गोपालसिंह कार्यालय",
                    source_date = "12 अप्रैल 2026",
                    verification_status = VerificationStatus.VERIFIED.name
                ),
                NewsUpdate(
                    title = "झालावाड़-झालरापाटन 198 में विशाल जनसमस्या निवारण शिविर संपन्न",
                    date = "10 अप्रैल 2026",
                    category = "जनसंवाद",
                    summary = "पिड़ावा एवं सुनेल क्षेत्र की जनसमस्याओं का ऑन-द-स्पॉट निस्तारण।",
                    fullContent = "पिड़ावा तहसील क्षेत्र में आयोजित जनसमस्या शिविर में टीम गोपालसिंह ने आमजन की समस्याओं को सुना।",
                    isPinned = false,
                    source_url = "टीम प्रेस विज्ञप्ति",
                    source_name = "टीम गोपालसिंह जनसंपर्क",
                    source_date = "10 अप्रैल 2026",
                    verification_status = VerificationStatus.VERIFIED.name
                )
            )
            newsDao.insertAllNews(initialNews)
        }

        val complaintsList = complaintDao.getAllComplaints().first()
        if (complaintsList.isEmpty()) {
            val initialComplaints = listOf(
                Complaint(
                    id = "JHL-198-2026-0001",
                    category = "पानी",
                    villageName = "हरनावदा गजा",
                    citizenName = "रामलाल गुर्जर",
                    mobileNumber = "9876543210",
                    description = "गाँव के वार्ड संख्या 3 में मुख्य पेयजल हैंडपंप खराब है एवं जल आपूर्ति में लीकेज है।",
                    dateFiled = "10 अप्रैल 2026",
                    status = ComplaintStatus.IN_PROGRESS.name,
                    lastUpdatedDate = "12 अप्रैल 2026",
                    remarks = "आंतरिक पंजीयन: जलदाय विभाग पिड़ावा के सहायक अभियंता को सूचित किया गया। यह शासकीय टोकन नंबर नहीं है।",
                    isInternalReference = true,
                    govtComplaintNumber = "आधिकारिक जानकारी उपलब्ध नहीं है",
                    source_url = "आंतरिक नागरिक पोर्टल",
                    source_name = "टीम गोपालसिंह आंतरिक पंजीयन",
                    source_date = "10 अप्रैल 2026",
                    verification_status = VerificationStatus.UNVERIFIED_LOCAL_SURVEY.name
                )
            )
            initialComplaints.forEach { complaintDao.insertComplaint(it) }
        }
    }

    // AI Sahayak Integration (Strict Data Grounded & Verification Aware)
    suspend fun getAiAnswer(userPrompt: String): String {
        val apiKey = com.example.BuildConfig.GEMINI_API_KEY
        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.connectTimeout = 15000
                connection.readTimeout = 15000
                connection.doOutput = true

                val systemPrompt = "आप 'टीम गोपालसिंह - हरनावदा गजा' (झालरापाटन विधानसभा क्षेत्र 198, जिला झालावाड़, राजस्थान) के एआई सहायक हैं। नियम: 1. केवल केवल सत्यापित सरकारी/डेटाबेस तथ्यों के आधार पर उत्तर दें। 2. जिस जानकारी का सरकारी स्रोत उपलब्ध न हो, स्पष्ट रूप से कहें: 'इस जानकारी का सत्यापित स्रोत उपलब्ध नहीं है।' 3. चुनाव परिणाम केवल ECI 2023 (विजेता वसुंधरा राजे - 1,38,831 वोट | निकटतम रामलाल - 85,638 वोट) तथा कुल पंजीकृत मतदाता (2,97,916) ही बताएं। 4. कभी भी मनगढ़ंत या अनुमानित संख्या/बजट/अधिकारी फोन नंबर न दें। 5. शिकायत ट्रैकिंग ID को केवल 'आंतरिक संदर्भ संख्या' बताएं, सरकारी शिकायत नंबर नहीं।"
                
                val jsonPayload = JSONObject().apply {
                    put("systemInstruction", JSONObject().apply {
                        put("parts", org.json.JSONArray().put(JSONObject().put("text", systemPrompt)))
                    })
                    put("contents", org.json.JSONArray().put(
                        JSONObject().apply {
                            put("parts", org.json.JSONArray().put(JSONObject().put("text", userPrompt)))
                        }
                    ))
                }

                OutputStreamWriter(connection.outputStream).use { writer ->
                    writer.write(jsonPayload.toString())
                    writer.flush()
                }

                if (connection.responseCode == 200) {
                    val responseText = connection.inputStream.bufferedReader().use { it.readText() }
                    val jsonResponse = JSONObject(responseText)
                    val candidates = jsonResponse.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val firstCandidate = candidates.getJSONObject(0)
                        val content = firstCandidate.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val reply = parts.getJSONObject(0).optString("text")
                            if (reply.isNotBlank()) return reply
                        }
                    }
                }
            } catch (e: Exception) {
                // Fallback to strict offline responder
            }
        }

        // Strict Grounded Offline AI Responder
        val queryLower = userPrompt.lowercase()
        return when {
            queryLower.contains("नमस्कार") || queryLower.contains("हेलो") || queryLower.contains("नमस्ते") || queryLower.contains("hi") || queryLower.contains("hello") ->
                "नमस्कार! 🙏 मैं 'टीम गोपालसिंह हरनावदा गजा' का एआई सहायक हूँ। झालरापाटन 198 क्षेत्र, ECI सत्यापित चुनाव आंकड़े, आंतरिक जनसमस्या दर्ज करने एवं सत्यापित ग्राम जानकारी हेतु आप प्रश्न पूछ सकते हैं।"

            queryLower.contains("झालरापाटन") || queryLower.contains("198") || queryLower.contains("विधानसभा") || queryLower.contains("चुनाव") || queryLower.contains("voter") ->
                "📍 **झालरापाटन विधानसभा क्षेत्र (AC-198) सत्यापित तथ्य (स्रोत: ECI 2023):**\n• **विधानसभा क्रमांक:** 198 (झालावाड़ जिला, राजस्थान)\n• **पंजीकृत मतदाता (2023):** 2,97,916 (स्रोत: CEO Rajasthan 2023)\n• **2023 चुनाव परिणाम:** वसुंधरा राजे (BJP) - 1,38,831 वोट (59.51%) [विजेता] | रामलाल (INC) - 85,638 वोट (36.71%)\n• **ग्राम पंचायत हरनावदा गजा LGD कोड:** 105194 (स्रोत: lgdirectory.gov.in)\n• **तहसीलें:** झालरापाटन, पिड़ावा, सुनेल, बकानी, असनावरा।"

            queryLower.contains("अधिकारी") || queryLower.contains("एसडीएम") || queryLower.contains("तहसीलदार") || queryLower.contains("कलेक्टर") ->
                "⚠️ **शासकीय निर्देशिका सूचना:** सरकारी अधिकारियों के व्यक्तिगत सीयूजी फोन/ईमेल स्थानांतरण योग्य होने के कारण वर्तमान में सत्यापित रूप से उपलब्ध नहीं हैं। केवल टीम सहायता केंद्र हेल्पलाइन 9166377972 पर संपर्क कर सकते हैं।"

            queryLower.contains("शिकायत") || queryLower.contains("समस्या") ->
                "📝 **आंतरिक जनसमस्या पंजीयन सूचना:** ऐप पर प्राप्त शिकायत ट्रैकिंग ID (उदा. JHL-198-2026-0001) केवल टीम गोपालसिंह का **आंतरिक संदर्भ ID** है। यह किसी सरकारी विभाग का आधिकारिक टोकन नंबर नहीं है।"

            queryLower.contains("विकास") || queryLower.contains("बजट") || queryLower.contains("लाख") || queryLower.contains("करोड़") ->
                "🏗️ **विकास कार्य ट्रैकिंग:** ऐप में दर्शाए गए विकास कार्यों के बजट एवं प्रगति प्रतिशत नागरिक सर्वेक्षण पर आधारित हैं। PWD/जलदाय विभाग के सरकारी स्वीकृति आदेशों का सत्यापन वर्तमान में लंबित (Verification Pending) है।"

            else ->
                "इस जानकारी का सत्यापित सरकारी/डेटाबेस स्रोत उपलब्ध नहीं है। अधिक सहायता हेतु टीम गोपालसिंह हेल्पलाइन 9166377972 पर संपर्क करें।"
        }
    }

    suspend fun getVerificationReportSummary(): VerificationReportSummary {
        val villages = villageDao.getAllVillages().first()
        val vikas = vikasKaryaDao.getAllVikasKarya().first()
        val complaints = complaintDao.getAllComplaints().first()
        val news = newsDao.getAllNews().first()

        val totalRecords = villages.size + vikas.size + complaints.size + news.size
        var verified = 0
        var pending = 0
        var localSurvey = 0
        var missingSource = 0

        val checkStatus = { status: String, sourceUrl: String ->
            when {
                status == VerificationStatus.VERIFIED.name -> verified++
                status == VerificationStatus.VERIFICATION_PENDING.name -> pending++
                status == VerificationStatus.UNVERIFIED_LOCAL_SURVEY.name -> localSurvey++
                sourceUrl.contains("उपलब्ध नहीं") || sourceUrl.isBlank() -> missingSource++
                else -> pending++
            }
        }

        villages.forEach { checkStatus(it.verification_status, it.source_url) }
        vikas.forEach { checkStatus(it.verification_status, it.source_url) }
        complaints.forEach { checkStatus(it.verification_status, it.source_url) }
        news.forEach { checkStatus(it.verification_status, it.source_url) }

        return VerificationReportSummary(
            totalRecords = totalRecords,
            verifiedCount = verified,
            pendingCount = pending,
            unverifiedSurveyCount = localSurvey,
            missingSourceCount = missingSource,
            duplicateCount = 0,
            conflictsCount = 2
        )
    }

    suspend fun getConflictReportItems(): List<DataConflictItem> {
        return listOf(
            DataConflictItem(
                entityType = "ग्राम संख्या",
                recordTitle = "AC-198 कुल ग्राम संख्या",
                appValue = "16 पंजीकृत गाँव (डेटाबेस सूची)",
                officialValue = "380+ राजस्व ग्राम",
                officialSource = "CEO Rajasthan / Revenue Dept Gazette 2023",
                conflictReason = "डेटाबेस में केवल स्थानीय सर्वेक्षण के 16 गाँव ही प्रविष्ट हैं, सम्पूर्ण 380+ नहीं।"
            ),
            DataConflictItem(
                entityType = "विकास बजट",
                recordTitle = "हरनावदा गजा मुख्य सड़क डामरीकरण",
                appValue = "₹ 42 लाख (स्थानीय नागरिक रिपोर्ट)",
                officialValue = "सत्यापन दस्तावेज अनुपलब्ध",
                officialSource = "PWD Jhalawar Portal (IFMS Sync Required)",
                conflictReason = "सरकारी स्वीकृति आदेश संख्या न होने से बजट सत्यापन लंबित है।"
            )
        )
    }

    fun getGovtSchemesList(): List<GovtScheme> {
        return listOf(
            GovtScheme(
                id = "1",
                name = "पीएम किसान सम्मान निधि",
                category = "कृषि एवं किसान",
                benefitText = "प्रतिवर्ष ₹6,000 की सीधी आर्थिक सहायता 3 किस्तों में किसानों के बैंक खाते में।",
                eligibility = "समस्त कृषि योग्य भूमि धारक किसान परिवार।",
                helpline = "155261 / 9166377972"
            ),
            GovtScheme(
                id = "2",
                name = "आयुष्मान भारत / स्वास्थ्य बीमा योजना",
                category = "स्वास्थ्य",
                benefitText = "निजी एवं सरकारी अस्पतालों में ₹25 लाख तक का कैशलेस इलाज नि:शुल्क।",
                eligibility = "NFSA/राशन कार्ड धारक एवं पात्र परिवार।",
                helpline = "14555 / 9166047972"
            ),
            GovtScheme(
                id = "3",
                name = "जल जीवन मिशन (हर घर जल)",
                category = "पेयजल",
                benefitText = "प्रत्येक ग्रामीण घर में शुद्ध पेयजल हेतु नि:शुल्क नल कनेक्शन।",
                eligibility = "समस्त ग्रामीण परिवार (हरनावदा गजा व संपूर्ण झालरापाटन 198 के गांव)।",
                helpline = "9166377972"
            ),
            GovtScheme(
                id = "4",
                name = "पीएम आवास योजना (ग्रामीण)",
                category = "आवास",
                benefitText = "पक्का मकान बनाने हेतु ₹1,20,000 की प्रत्यक्ष आर्थिक सहायता + मनरेगा मजदूरी।",
                eligibility = "कच्चे मकानों में रहने वाले बेघर एवं निर्धन ग्रामीण परिवार।",
                helpline = "9166047972"
            ),
            GovtScheme(
                id = "5",
                name = "पीएम कुसुम योजना (सौर ऊर्जा पंप)",
                category = "कृषि एवं ऊर्जा",
                benefitText = "खेत में सिंचाई हेतु सौर ऊर्जा पंप स्थापित करने पर 60% से 80% सब्सिडी।",
                eligibility = "कृषि भूमिधारक किसान जिनके पास बिजली कनेक्शन उपलब्ध नहीं है।",
                helpline = "9166377972"
            )
        )
    }
}
