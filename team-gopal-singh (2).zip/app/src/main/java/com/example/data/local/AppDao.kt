package com.example.data.local

import androidx.room.*
import com.example.data.models.AuditLog
import com.example.data.models.Complaint
import com.example.data.models.NewsUpdate
import com.example.data.models.VikasKarya
import com.example.data.models.Village
import kotlinx.coroutines.flow.Flow

@Dao
interface ComplaintDao {
    @Query("SELECT * FROM complaints WHERE is_deleted = 0 ORDER BY dateFiled DESC")
    fun getAllComplaints(): Flow<List<Complaint>>

    @Query("SELECT * FROM complaints WHERE id = :id AND is_deleted = 0 LIMIT 1")
    suspend fun getComplaintById(id: String): Complaint?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComplaint(complaint: Complaint)

    @Query("UPDATE complaints SET status = :status, remarks = :remarks, lastUpdatedDate = :date, updated_at = :date WHERE id = :id")
    suspend fun updateComplaintStatus(id: String, status: String, remarks: String, date: String)

    @Query("UPDATE complaints SET is_deleted = 1 WHERE id = :id")
    suspend fun deleteComplaint(id: String)
}

@Dao
interface VikasKaryaDao {
    @Query("SELECT * FROM vikas_karya WHERE is_deleted = 0 ORDER BY id DESC")
    fun getAllVikasKarya(): Flow<List<VikasKarya>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVikasKarya(vikasKarya: VikasKarya)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllVikasKarya(list: List<VikasKarya>)
}

@Dao
interface VillageDao {
    @Query("SELECT * FROM villages WHERE is_deleted = 0 ORDER BY name ASC")
    fun getAllVillages(): Flow<List<Village>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllVillages(villages: List<Village>)
}

@Dao
interface NewsDao {
    @Query("SELECT * FROM news_updates WHERE is_deleted = 0 ORDER BY isPinned DESC, id DESC")
    fun getAllNews(): Flow<List<NewsUpdate>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNews(news: NewsUpdate)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllNews(list: List<NewsUpdate>)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100")
    fun getAllAuditLogs(): Flow<List<AuditLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLog)
}

