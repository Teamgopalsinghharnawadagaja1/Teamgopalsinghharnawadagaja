package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.models.AuditLog
import com.example.data.models.Complaint
import com.example.data.models.NewsUpdate
import com.example.data.models.VikasKarya
import com.example.data.models.Village

@Database(
    entities = [Complaint::class, VikasKarya::class, Village::class, NewsUpdate::class, AuditLog::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun complaintDao(): ComplaintDao
    abstract fun vikasKaryaDao(): VikasKaryaDao
    abstract fun villageDao(): VillageDao
    abstract fun newsDao(): NewsDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "team_gopal_singh_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

