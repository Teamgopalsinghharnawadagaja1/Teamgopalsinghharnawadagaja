package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.models.*
import com.example.data.repository.AppRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = AppRepository(application)

    val complaints: StateFlow<List<Complaint>> = repository.allComplaints
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vikasKarya: StateFlow<List<VikasKarya>> = repository.allVikasKarya
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val villages: StateFlow<List<Village>> = repository.allVillages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val news: StateFlow<List<NewsUpdate>> = repository.allNews
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val schemes: List<GovtScheme> = repository.getGovtSchemesList()

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _complaintCategoryFilter = MutableStateFlow("सभी")
    val complaintCategoryFilter: StateFlow<String> = _complaintCategoryFilter.asStateFlow()

    private val _vikasStatusFilter = MutableStateFlow("सभी")
    val vikasStatusFilter: StateFlow<String> = _vikasStatusFilter.asStateFlow()

    private val _isAdminMode = MutableStateFlow(false)
    val isAdminMode: StateFlow<Boolean> = _isAdminMode.asStateFlow()

    private val _currentAdminUser = MutableStateFlow<AdminUser?>(null)
    val currentAdminUser: StateFlow<AdminUser?> = _currentAdminUser.asStateFlow()

    val auditLogs: StateFlow<List<AuditLog>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _backupInfo = MutableStateFlow(repository.getBackupStatusInfo())
    val backupInfo: StateFlow<BackupStatusInfo> = _backupInfo.asStateFlow()

    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    private val _fileValidationError = MutableStateFlow<String?>(null)
    val fileValidationError: StateFlow<String?> = _fileValidationError.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = "AI",
                text = "नमस्कार! 🙏 मैं 'टीम गोपालसिंह हरनावदा गजा' का एआई सहायक हूँ। झालरापाटन 198 क्षेत्र, विकास कार्यों, जनसमस्या दर्ज करने या गांव की जानकारी हेतु आप कोई भी सवाल पूछ सकते हैं।"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    private val _submissionSuccessMessage = MutableStateFlow<String?>(null)
    val submissionSuccessMessage: StateFlow<String?> = _submissionSuccessMessage.asStateFlow()

    private val _verificationSummary = MutableStateFlow<VerificationReportSummary?>(null)
    val verificationSummary: StateFlow<VerificationReportSummary?> = _verificationSummary.asStateFlow()

    private val _conflictReportItems = MutableStateFlow<List<DataConflictItem>>(emptyList())
    val conflictReportItems: StateFlow<List<DataConflictItem>> = _conflictReportItems.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            repository.seedInitialDataIfNeeded()
            _verificationSummary.value = repository.getVerificationReportSummary()
            _conflictReportItems.value = repository.getConflictReportItems()
        }
    }

    fun setSelectedTab(index: Int) {
        _selectedTab.value = index
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = com.example.util.InputSanitizer.sanitizeTextInput(query)
    }

    fun setComplaintCategoryFilter(category: String) {
        _complaintCategoryFilter.value = category
    }

    fun setVikasStatusFilter(status: String) {
        _vikasStatusFilter.value = status
    }

    fun toggleAdminMode() {
        if (!_isAdminMode.value && _currentAdminUser.value == null) {
            // Default login as Super Admin for demonstration
            loginAdmin("gopalsingh_admin", AdminRole.SUPER_ADMIN, "1234")
        }
        _isAdminMode.value = !_isAdminMode.value
    }

    fun loginAdmin(username: String, role: AdminRole, pin: String): Boolean {
        if (pin == "1234" || pin == "198198") {
            val user = AdminUser(
                username = com.example.util.InputSanitizer.sanitizeTextInput(username),
                role = role,
                sessionToken = "SESSION_TOKEN_${System.currentTimeMillis()}",
                isMfaVerified = true,
                lastLoginTimestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            )
            _currentAdminUser.value = user
            _isAdminMode.value = true

            viewModelScope.launch(Dispatchers.IO) {
                repository.recordAuditLog(
                    adminId = user.username,
                    role = user.role.roleKey,
                    action = "ADMIN_LOGIN",
                    tableName = "auth_sessions",
                    recordId = user.sessionToken,
                    oldValue = "DISCONNECTED",
                    newValue = "CONNECTED",
                    notes = "Admin session created safely"
                )
            }
            return true
        }
        return false
    }

    fun logoutAdmin() {
        val user = _currentAdminUser.value
        if (user != null) {
            viewModelScope.launch(Dispatchers.IO) {
                repository.recordAuditLog(
                    adminId = user.username,
                    role = user.role.roleKey,
                    action = "ADMIN_LOGOUT",
                    tableName = "auth_sessions",
                    recordId = user.sessionToken,
                    oldValue = "CONNECTED",
                    newValue = "LOGGED_OUT",
                    notes = "Admin session terminated safely"
                )
            }
        }
        _currentAdminUser.value = null
        _isAdminMode.value = false
    }

    fun clearSubmissionMessage() {
        _submissionSuccessMessage.value = null
        _fileValidationError.value = null
    }

    fun validateAttachment(fileName: String, mimeType: String, sizeBytes: Long): Boolean {
        val result = com.example.util.FileSecurityUtil.validateAndSanitizeFile(fileName, mimeType, sizeBytes)
        if (!result.isValid) {
            _fileValidationError.value = result.errorMessage
            return false
        }
        _fileValidationError.value = null
        return true
    }

    fun submitNewComplaint(
        category: String,
        villageName: String,
        citizenName: String,
        mobileNumber: String,
        description: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val cleanName = com.example.util.InputSanitizer.sanitizeTextInput(citizenName)
            val cleanDesc = com.example.util.InputSanitizer.sanitizeTextInput(description)
            val generatedId = repository.addComplaint(category, villageName, cleanName, mobileNumber, cleanDesc)
            _submissionSuccessMessage.value = "जनसमस्या सफलतापूर्वक दर्ज हो गई है! आपकी आंतरिक संदर्भ ID: $generatedId"
        }
    }

    fun updateComplaintStatus(complaintId: String, newStatus: String, remarks: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val cleanRemarks = com.example.util.InputSanitizer.sanitizeTextInput(remarks)
            repository.updateComplaintStatus(complaintId, newStatus, cleanRemarks, _currentAdminUser.value)
        }
    }

    fun addNewVikasKarya(title: String, category: String, villageName: String, budget: String, description: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val today = java.text.SimpleDateFormat("dd अप्रैल 2026", java.util.Locale("hi", "IN")).format(java.util.Date())
            val newItem = VikasKarya(
                title = com.example.util.InputSanitizer.sanitizeTextInput(title),
                category = category,
                villageName = villageName,
                estimatedBudget = budget,
                status = VikasStatus.IN_PROGRESS.name,
                progressPercentage = 15,
                description = com.example.util.InputSanitizer.sanitizeTextInput(description),
                startDate = today,
                targetCompletionDate = "31 जुलाई 2026"
            )
            repository.addVikasKarya(newItem, _currentAdminUser.value)
        }
    }

    fun postNewsUpdate(title: String, category: String, summary: String, content: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val today = java.text.SimpleDateFormat("dd अप्रैल 2026", java.util.Locale("hi", "IN")).format(java.util.Date())
            val newsItem = NewsUpdate(
                title = com.example.util.InputSanitizer.sanitizeTextInput(title),
                date = today,
                category = category,
                summary = com.example.util.InputSanitizer.sanitizeTextInput(summary),
                fullContent = com.example.util.InputSanitizer.sanitizeTextInput(content),
                isPinned = false
            )
            repository.addNews(newsItem, _currentAdminUser.value)
        }
    }

    fun sendAiUserMessage(userText: String) {
        val sanitized = com.example.util.InputSanitizer.sanitizeTextInput(userText)
        if (sanitized.isBlank()) return
        val userMsg = ChatMessage(sender = "USER", text = sanitized)
        _chatMessages.value = _chatMessages.value + userMsg
        _isAiThinking.value = true

        viewModelScope.launch(Dispatchers.IO) {
            val aiReply = repository.getAiAnswer(sanitized)
            val aiMsg = ChatMessage(sender = "AI", text = aiReply)
            _chatMessages.value = _chatMessages.value + aiMsg
            _isAiThinking.value = false
        }
    }

}
