import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
void main(){TestWidgetsFlutterBinding.ensureInitialized();test('feature registry contains 3312 requirements',()async{final raw=await rootBundle.loadString('assets/requirements/feature_registry.json');final j=jsonDecode(raw) as Map<String,dynamic>;expect((j['features'] as List).length,3312);expect((j['categories'] as List).length,50);});}
