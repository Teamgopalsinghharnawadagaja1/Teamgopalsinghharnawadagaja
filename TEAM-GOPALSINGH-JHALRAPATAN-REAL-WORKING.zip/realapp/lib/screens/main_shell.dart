import 'package:flutter/material.dart';
import '../services/app_data.dart';
import '../services/local_store.dart';
import 'module_screen.dart';
import 'search_screen.dart';
import 'complaint_screen.dart';
import 'profile_screen.dart';
import 'home_screen.dart';

class MainShell extends StatefulWidget { final AppData data; const MainShell({super.key,required this.data}); @override State<MainShell> createState()=>_State(); }
class _State extends State<MainShell>{ int index=0; List<String> favs=[]; @override void initState(){super.initState();_load();} Future<void> _load()async{favs=await LocalStore.favorites();if(mounted)setState((){});} 
Widget page(){switch(index){case 1:return SearchScreen(data:data,onOpen:(f)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ModuleScreen(module:data.modules.firstWhere((m)=>m.name==f.category),initialFeature:f,onFavoritesChanged:_load)));case 2:return ComplaintScreen();case 3:return ProfileScreen();default:return HomeScreen(data:data,onOpen:(m)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ModuleScreen(module:m,onFavoritesChanged:_load))));}}
@override Widget build(BuildContext c)=>Scaffold(body:page(),bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.search),label:'Search'),NavigationDestination(icon:Icon(Icons.assignment_outlined),selectedIcon:Icon(Icons.assignment),label:'शिकायत'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile')])); }
