import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/models.dart';

class AppData {
  final List<AppModule> modules;
  final List<AppFeature> features;
  const AppData._(this.modules, this.features);

  static Future<AppData> load() async {
    final raw = await rootBundle.loadString('assets/requirements/feature_registry.json');
    final json = jsonDecode(raw) as Map<String, dynamic>;
    final list = (json['features'] as List).map((e) => AppFeature.fromJson(Map<String, dynamic>.from(e))).toList();
    final grouped = <String, List<AppFeature>>{};
    for (final f in list) { grouped.putIfAbsent(f.category, () => []).add(f); }
    return AppData._(grouped.entries.map((e) => AppModule(e.key, e.value)).toList(), list);
  }
}
