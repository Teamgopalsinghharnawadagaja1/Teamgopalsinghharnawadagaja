import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

class FirebaseService {
  static bool initialized = false;
  static Future<void> init() async {
    try {
      if (Firebase.apps.isEmpty) await Firebase.initializeApp();
      initialized = true;
    } catch (_) {
      initialized = false;
    }
  }

  static Future<bool> saveComplaint(Map<String, dynamic> data) async {
    if (!initialized) return false;
    try {
      await FirebaseFirestore.instance.collection('complaints').doc(data['id'] as String).set({...data, 'createdAt': FieldValue.serverTimestamp()});
      return true;
    } catch (_) { return false; }
  }
}
