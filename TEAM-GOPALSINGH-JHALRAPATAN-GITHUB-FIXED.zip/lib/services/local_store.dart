import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class LocalStore {
  static const complaintsKey = 'jhalawar_one_complaints';
  static const favoritesKey = 'jhalawar_one_favorites';
  static const profileKey = 'jhalawar_one_profile';

  static Future<List<Map<String, dynamic>>> complaints() async {
    final p = SharedPreferencesAsync();
    final raw = await p.getString(complaintsKey);
    if (raw == null || raw.isEmpty) return [];
    try { return (jsonDecode(raw) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList(); } catch (_) { return []; }
  }
  static Future<void> saveComplaints(List<Map<String, dynamic>> v) async => SharedPreferencesAsync().setString(complaintsKey, jsonEncode(v));
  static Future<List<String>> favorites() async => await SharedPreferencesAsync().getStringList(favoritesKey) ?? [];
  static Future<void> saveFavorites(List<String> v) async => SharedPreferencesAsync().setStringList(favoritesKey, v);
  static Future<Map<String, dynamic>> profile() async {
    final raw = await SharedPreferencesAsync().getString(profileKey);
    if (raw == null) return {};
    try { return Map<String, dynamic>.from(jsonDecode(raw)); } catch (_) { return {}; }
  }
  static Future<void> saveProfile(Map<String, dynamic> v) async => SharedPreferencesAsync().setString(profileKey, jsonEncode(v));
}
