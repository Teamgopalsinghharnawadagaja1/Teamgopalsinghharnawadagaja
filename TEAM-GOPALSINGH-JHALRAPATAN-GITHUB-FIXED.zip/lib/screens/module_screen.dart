import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/theme.dart';
import '../models/models.dart';
import '../services/local_store.dart';

class ModuleScreen extends StatefulWidget {
  final AppModule module;
  final AppFeature? initialFeature;
  final VoidCallback? onFavoritesChanged;

  const ModuleScreen({
    super.key,
    required this.module,
    this.initialFeature,
    this.onFavoritesChanged,
  });

  @override
  State<ModuleScreen> createState() => _ModuleScreenState();
}

class _ModuleScreenState extends State<ModuleScreen> {
  String query = '';
  List<String> favorites = <String>[];

  @override
  void initState() {
    super.initState();
    LocalStore.favorites().then((value) {
      if (mounted) setState(() => favorites = value);
    });
    if (widget.initialFeature != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _openFeature(widget.initialFeature!);
      });
    }
  }

  void _openFeature(AppFeature feature) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => FeatureDetail(feature: feature)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final list = widget.module.features
        .where((feature) => feature.name.toLowerCase().contains(query.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.module.name),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(66),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: TextField(
              onChanged: (value) => setState(() => query = value),
              decoration: const InputDecoration(
                hintText: 'इस मॉड्यूल में खोजें',
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
        ),
      ),
      body: list.isEmpty
          ? const Center(child: Text('कोई सुविधा नहीं मिली'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: list.length,
              itemBuilder: (context, index) {
                final feature = list[index];
                final id = feature.id.toString();
                final isFavorite = favorites.contains(id);
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppTheme.lightBlue,
                      child: Text('${index + 1}', style: const TextStyle(color: AppTheme.blue)),
                    ),
                    title: Text(feature.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(feature.status),
                    trailing: IconButton(
                      icon: Icon(isFavorite ? Icons.star : Icons.star_border, color: isFavorite ? Colors.amber : null),
                      onPressed: () async {
                        final updated = [...favorites];
                        if (isFavorite) {
                          updated.remove(id);
                        } else {
                          updated.add(id);
                        }
                        await LocalStore.saveFavorites(updated);
                        if (mounted) setState(() => favorites = updated);
                        widget.onFavoritesChanged?.call();
                      },
                    ),
                    onTap: () => _openFeature(feature),
                  ),
                );
              },
            ),
    );
  }
}

class FeatureDetail extends StatelessWidget {
  final AppFeature feature;
  const FeatureDetail({super.key, required this.feature});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Feature')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(feature.name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          _infoCard('स्थिति', feature.status),
          _infoCard('Implementation Area', feature.area),
          _infoCard('Verification', feature.verification),
          _infoCard('Security', feature.security),
          _infoCard('Testing', feature.testing),
          if (feature.source.trim().isNotEmpty && feature.source.trim().toLowerCase() != 'nan')
            Card(
              child: ListTile(
                leading: const Icon(Icons.verified_outlined),
                title: const Text('Official Source'),
                subtitle: Text(feature.source),
                trailing: const Icon(Icons.open_in_new),
                onTap: () async {
                  final uri = Uri.tryParse(feature.source.trim());
                  if (uri != null && await canLaunchUrl(uri)) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
              ),
            )
          else
            const Card(
              child: ListTile(
                leading: Icon(Icons.info_outline),
                title: Text('Official source उपलब्ध नहीं है'),
                subtitle: Text('बिना सत्यापन के सरकारी जानकारी नहीं दिखाई जाएगी।'),
              ),
            ),
        ],
      ),
    );
  }

  Widget _infoCard(String title, String value) {
    final text = value.trim().isEmpty || value.trim().toLowerCase() == 'nan' ? 'Not specified' : value.trim();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(text),
          ],
        ),
      ),
    );
  }
}
