import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/app_data.dart';
import '../services/local_store.dart';
import 'complaint_screen.dart';
import 'home_screen.dart';
import 'module_screen.dart';
import 'profile_screen.dart';
import 'search_screen.dart';

class MainShell extends StatefulWidget {
  final AppData data;
  const MainShell({super.key, required this.data});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  Future<void> _refreshFavorites() async {
    await LocalStore.favorites();
    if (mounted) setState(() {});
  }

  void _openFeature(AppFeature feature) {
    final module = widget.data.modules.firstWhere(
      (m) => m.name == feature.category,
      orElse: () => AppModule(feature.category, [feature]),
    );
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ModuleScreen(
          module: module,
          initialFeature: feature,
          onFavoritesChanged: _refreshFavorites,
        ),
      ),
    );
  }

  Widget _page() {
    switch (index) {
      case 1:
        return SearchScreen(data: widget.data, onOpen: _openFeature);
      case 2:
        return const ComplaintScreen();
      case 3:
        return const ProfileScreen();
      default:
        return HomeScreen(
          data: widget.data,
          onOpen: (module) => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ModuleScreen(
                module: module,
                onFavoritesChanged: _refreshFavorites,
              ),
            ),
          ),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _page(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'शिकायत'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
