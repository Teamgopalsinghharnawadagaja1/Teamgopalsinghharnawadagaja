import 'package:flutter/material.dart';

class AppTheme {
  static const blue = Color(0xFF0B4AA2);
  static const lightBlue = Color(0xFFEAF2FF);
  static ThemeData data() => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light),
    scaffoldBackgroundColor: const Color(0xFFF5F7FB),
    appBarTheme: const AppBarTheme(backgroundColor: blue, foregroundColor: Colors.white, centerTitle: false),
    cardTheme: const CardThemeData(margin: EdgeInsets.only(bottom: 10), elevation: 1),
    inputDecorationTheme: const InputDecorationTheme(filled: true, fillColor: Colors.white, border: OutlineInputBorder(), enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFD9E0EA))), focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: blue, width: 2))),
  );
}
