class AppFeature {
  final int id;
  final String category;
  final String name;
  final String status;
  final String area;
  final String source;
  final String verification;
  final String security;
  final String testing;

  const AppFeature({required this.id, required this.category, required this.name, required this.status, required this.area, required this.source, required this.verification, required this.security, required this.testing});

  factory AppFeature.fromJson(Map<String, dynamic> j) => AppFeature(
    id: (j['id'] as num?)?.toInt() ?? 0,
    category: '${j['category'] ?? ''}',
    name: '${j['feature'] ?? ''}',
    status: '${j['status'] ?? 'Planned'}',
    area: '${j['implementation_area'] ?? ''}',
    source: '${j['official_source'] ?? ''}',
    verification: '${j['verification'] ?? ''}',
    security: '${j['security'] ?? ''}',
    testing: '${j['testing'] ?? ''}',
  );
}

class AppModule {
  final String name;
  final List<AppFeature> features;
  const AppModule(this.name, this.features);
}
