import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../services/app_data.dart';
import '../services/firebase_service.dart';
import '../screens/main_shell.dart';

class TeamGopalSinghApp extends StatefulWidget { const TeamGopalSinghApp({super.key}); @override State<TeamGopalSinghApp> createState()=>_AppState(); }
class _AppState extends State<TeamGopalSinghApp> {
  late Future<AppData> future;
  @override void initState(){ super.initState(); FirebaseService.init(); future=AppData.load(); }
  @override Widget build(BuildContext context)=>MaterialApp(title:'Jhalawar One',debugShowCheckedModeBanner:false,theme:AppTheme.data(),home:FutureBuilder<AppData>(future:future,builder:(c,s){if(s.connectionState!=ConnectionState.done)return const Scaffold(body:Center(child:CircularProgressIndicator()));if(s.hasError)return Scaffold(body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Text('App data load failed: ${s.error}'))));return MainShell(data:s.data!);}),);
}
