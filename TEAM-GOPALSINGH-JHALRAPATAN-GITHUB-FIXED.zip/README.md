# Team Gopal Singh Jhalrapatan — Working App

This version replaces the empty module demo with a functional Flutter app shell driven by the 3,312-row master registry.

## Working now
- Jhalawar One style dashboard
- 50 modules loaded from the master registry
- 3,312 feature records loaded at runtime
- Module search
- Global feature search
- Feature detail pages with source/verification/security/testing fields
- Favorites persisted locally
- Complaint creation with local ID/history and optional Firestore sync
- Profile persistence
- Offline-safe local data for complaints/profile/favorites
- Optional Firebase initialization
- GitHub Actions debug APK build

## Honest scope
Government live data, official APIs, maps credentials, OTP authentication, push notification backend, and admin operations require their respective external configuration. The app does not fabricate government data when a source is unavailable.

## Firebase
Set the GitHub repository secret `FIREBASE_GOOGLE_SERVICES_JSON` to the contents of the downloaded Firebase Android config. Do not commit the JSON to a public repository.

## Build
`flutter pub get`
`flutter analyze`
`flutter test`
`flutter build apk --debug`
