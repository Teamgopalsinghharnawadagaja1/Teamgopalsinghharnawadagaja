# Team Gopal Singh — Jhalrapatan Civic Services App

Branding has been adapted from the user-supplied logo for:
- विधानसभा क्षेत्र 198 — झालरापाटन
- हरनावदा गजा
- तहसील पिड़ावा
- जिला झालावाड़, राजस्थान

## Included
- Hindi-first responsive Web/PWA
- Supplied logo branding
- Home dashboard
- Mobile login/session
- Complaint / जनसमस्या registration
- GPS capture
- Complaint list and case IDs
- Development projects
- Schemes information
- Village information
- Contact page
- SQLite database
- REST API
- PWA manifest/service worker

## Project layout
This is now one combined project:
- `server.js` + root `package.json` — Express + SQLite REST API (complaints, projects, schemes, audit logs, OTP auth).
- `client/` — the full Hindi Gram Panchayat directory React app (Vite + TypeScript), built as a static site and served by the same Express server.
- `public/` — minimal fallback page, only used if `client/dist` hasn't been built yet.

The two apps share the same civic domain (Jhalawar / झालरापाटन), so `client/`'s grievance form now also POSTs to the backend's `/api/complaints` endpoint (best-effort, via `client/src/utils/api.ts`) in addition to saving locally — the app keeps working fully offline as a PWA even if that sync fails or the citizen hasn't logged in.

## Local run
1. Install Node.js 20+
2. `npm run setup` (installs both root and `client/` dependencies, then builds the client)
3. `npm start`
4. Open `http://localhost:3000`

For active development on the client with hot reload, run `npm run dev --prefix client` (Vite dev server on port 3000) in one terminal and `npm run dev` (API on port 3000 too — change `PORT` env var for one of them) in another.

Development OTP is `123456` and must be replaced with a real OTP provider before production.

## Important
This build is a working civic/public-service application foundation. It does not invent or certify government facts. Official scheme, election, officer, finance, village and other public records should be populated from authoritative sources and marked with source, verification status and last-updated date.

For a production release, real hosting, SMS, object storage, push notifications, maps, security testing, backups, monitoring and Android signing/release still need to be configured.
