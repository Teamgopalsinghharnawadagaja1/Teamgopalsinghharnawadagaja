# FINAL SETUP — Team Gopal Singh / Jhalrapatan

## 1. GitHub APK
Push this folder to GitHub and run **Actions → Build APK**. The workflow builds the React/PWA client and packages it into the Android WebView APK.

## 2. Local backend
Copy `.env.example` to `.env`, set `JWT_SECRET`, then:
`npm run setup`
`npm start`

Health: `/api/health`

## 3. Docker
Copy `.env.example` to `.env` and replace `JWT_SECRET` with a long random value.
Then run:
`docker compose up -d --build`

Persist `./data`.

## 4. OTP
`ALLOW_DEV_OTP=true` is development-only. Production login requires a real SMS/OTP provider. Do not expose the development OTP in production.

## 5. Android/PWA backend
When Android/PWA is deployed separately from the Express server, set `VITE_API_BASE` before the client build, for example:
`VITE_API_BASE=https://api.example.com/api`
If the React app is served by the same Express server, leave it unset and `/api` is used automatically.

## 6. Data verification
Only government-source-backed records may be labelled Verified. Everything else must remain Verification Pending / needs_verification until a source is recorded.
