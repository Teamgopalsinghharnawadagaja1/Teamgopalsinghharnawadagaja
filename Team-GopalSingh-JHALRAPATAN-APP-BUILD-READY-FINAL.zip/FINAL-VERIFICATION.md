# Final CI Verification Package

This package has been cleaned for an all-in-one GitHub Actions build.

## Fixed
- GitHub Actions supports both a repository-root project and a project ZIP.
- Root and client Node dependencies are installed in the correct locations.
- Vite is explicitly verified before the web build.
- TypeScript is checked before packaging the Android app.
- Java 17 and Gradle 9.3.1 are provisioned in CI.
- A Gradle wrapper is generated automatically when the source ZIP does not contain one.
- The Android debug build no longer references a missing `debug.keystore`; Gradle uses its normal debug signing.
- The web build is copied into the APK assets.
- APK existence is verified before artifact upload.
- Source-structure verification checks the actual workflow filename.

## Important
A successful ZIP preparation cannot itself prove that GitHub Actions has completed successfully. The final proof is the GitHub Actions run and its generated APK artifact.
