plugins {
    id("com.android.application")
}

android {
    namespace = "com.teamgopalsingh.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.teamgopalsingh.app"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}

// The CI workflow builds the Vite client first. This task packages that
// verified web build into the Android WebView assets without running npm
// from Gradle, avoiding duplicate installs and network-dependent Gradle tasks.
val clientDistDir = File(rootDir, "../client/dist")
val webAssetsDir = File(projectDir, "src/main/assets/www")

tasks.register<Delete>("cleanWebAssets") {
    delete(webAssetsDir)
}

tasks.register<Copy>("copyWebAssets") {
    dependsOn("cleanWebAssets")
    doFirst {
        if (!File(clientDistDir, "index.html").isFile) {
            throw GradleException("client/dist/index.html is missing. Build the web client before building the APK.")
        }
    }
    from(clientDistDir)
    into(webAssetsDir)
}

tasks.named("preBuild") {
    dependsOn("copyWebAssets")
}
