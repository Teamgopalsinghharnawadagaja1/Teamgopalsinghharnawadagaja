#!/usr/bin/env bash
set -euo pipefail

fail() { echo "ERROR: $1"; exit 1; }

[ -f "package.json" ] || fail "package.json missing"
[ -f "package-lock.json" ] || fail "package-lock.json missing"
[ -f "client/package.json" ] || fail "client/package.json missing"
[ -f "client/index.html" ] || fail "client/index.html missing"
[ -f "client/vite.config.ts" ] || fail "client/vite.config.ts missing"
[ -f "android/settings.gradle.kts" ] || fail "android/settings.gradle.kts missing"
[ -f "android/build.gradle.kts" ] || fail "android/build.gradle.kts missing"
[ -f "android/app/build.gradle.kts" ] || fail "android/app/build.gradle.kts missing"
[ -f "android/app/src/main/AndroidManifest.xml" ] || fail "AndroidManifest.xml missing"
[ -f "android/app/src/main/java/com/teamgopalsingh/app/MainActivity.kt" ] || fail "MainActivity.kt missing"
[ -f ".github/workflows/build-apk.yml" ] || fail "build-apk.yml missing"

if grep -q 'storeFile = file("../debug.keystore")' android/app/build.gradle.kts; then
  fail "app build file references a missing debug.keystore"
fi

if grep -q 'npm install' android/app/build.gradle.kts || grep -q 'npm run build' android/app/build.gradle.kts; then
  fail "Gradle must not run npm install/build; CI builds the web client separately"
fi

echo "FINAL structure verification: PASSED"
