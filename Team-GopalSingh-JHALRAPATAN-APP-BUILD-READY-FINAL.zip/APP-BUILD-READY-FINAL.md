# APP BUILD-READY FINAL SET

This package is the app-buildable source set for Team Gopal Singh / Jhalrapatan.

Included:
- React/Vite web/PWA client
- Android WebView shell
- Gradle/AGP setup
- GitHub Actions APK workflow
- Express + SQLite backend
- Docker/Docker Compose deployment files
- environment examples
- verification and official-source/data-audit documentation

Build path:
1. Upload/extract this repository to GitHub.
2. Push to `main`/`master` or run Actions > Build APK manually.
3. The workflow installs Node 22 and Java 17, builds the client, prepares the Gradle wrapper, builds the debug APK, verifies it, and uploads it as `JHALRAPATAN-debug-apk`.

Important:
- Production SMS OTP and a production JWT secret require real deployment credentials.
- The Android shell can run the bundled app offline. Central backend features require the API to be deployed and the frontend build to use `VITE_API_BASE`.
- No fake government records are marked Verified; verification status follows the project's official-source rule.

Static structure verification: PASSED.
