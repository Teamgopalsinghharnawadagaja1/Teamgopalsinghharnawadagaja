package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComplaintsScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Register Complaint, 1: Track / Admin List
    val userRole by viewModel.userRole.collectAsState()
    val complaints by viewModel.complaints.collectAsState()
    val context = LocalContext.current

    // Form states
    var citizenName by remember { mutableStateOf("") }
    var citizenPhone by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("पेयजल आपूर्ति") }
    var location by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    val categories = listOf("पेयजल आपूर्ति", "विद्युत (स्ट्रीट लाइट)", "सड़क सुधार व खड्डे", "सफाई व कचरा निस्तारण", "राशन व खाद्य सुरक्षा", "अन्य प्रशासनिक कार्य")

    LaunchedEffect(Unit) {
        viewModel.complaintSubmissionResult.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            selectedTab = 1
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TabRow(selectedTabIndex = selectedTab, containerColor = MaterialTheme.colorScheme.surface) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("नवीन शिकायत दर्ज करें") },
                icon = { Icon(Icons.Default.AddComment, contentDescription = null) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("शिकायत स्थिति व ट्रैकिंग (${complaints.size})") },
                icon = { Icon(Icons.Default.TrackChanges, contentDescription = null) }
            )
        }

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "राजस्थान संपर्क एवं झालरापाटन प्रशासन शिकायत दर्ज केंद्र",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "आपकी शिकायत सीधे संबंधित विभाग के नोडल अधिकारी को प्रेषित की जाएगी।",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                item {
                    OutlinedTextField(
                        value = citizenName,
                        onValueChange = { citizenName = it },
                        label = { Text("आपका नाम") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("complaint_name_input"),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = citizenPhone,
                        onValueChange = { citizenPhone = it },
                        label = { Text("मोबाइल नंबर") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("complaint_phone_input"),
                        singleLine = true
                    )
                }

                item {
                    Text(text = "शिकायत की श्रेणी चुने:", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column {
                            categories.chunked(2).forEach { rowCats ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    rowCats.forEach { cat ->
                                        FilterChip(
                                            selected = category == cat,
                                            onClick = { category = cat },
                                            label = { Text(cat, fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("ग्राम / वार्ड / स्थान विवरण") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("complaint_location_input"),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("शिकायत का विस्तृत विवरण") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("complaint_desc_input")
                    )
                }

                item {
                    Button(
                        onClick = {
                            if (description.isBlank()) {
                                Toast.makeText(context, "कृपया शिकायत विवरण दर्ज करें", Toast.LENGTH_SHORT).show()
                            } else {
                                viewModel.registerComplaint(citizenName, citizenPhone, category, location, description)
                                citizenName = ""
                                citizenPhone = ""
                                location = ""
                                description = ""
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_complaint_btn")
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("शिकायत दर्ज करें (Submit Ticket)", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(complaints) { item ->
                    ComplaintCard(complaint = item, userRole = userRole, onUpdateStatus = { newStatus, notes ->
                        viewModel.updateComplaintStatus(item, newStatus, notes)
                    })
                }
            }
        }
    }
}

@Composable
fun ComplaintCard(
    complaint: ComplaintEntity,
    userRole: String,
    onUpdateStatus: (String, String) -> Unit
) {
    var showAdminDialog by remember { mutableStateOf(false) }
    var actionNotes by remember { mutableStateOf(complaint.resolutionNotes) }

    val statusColor = when (complaint.status) {
        "Resolved" -> Color(0xFF2E7D32)
        "In Progress" -> Color(0xFFE65100)
        else -> Color(0xFFC62828)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "टिकट: ${complaint.ticketNumber}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Surface(
                    color = statusColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = when(complaint.status) {
                            "Resolved" -> "निस्तारित"
                            "In Progress" -> "प्रक्रियाधीन"
                            else -> "दर्ज (Pending)"
                        },
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "आवेदक: ${complaint.citizenName} (${complaint.citizenPhone})", fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(text = "श्रेणी: ${complaint.category} | स्थान: ${complaint.villageOrWard}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "विवरण: ${complaint.description}", fontSize = 13.sp)

            Spacer(modifier = Modifier.height(8.dp))
            Divider()
            Spacer(modifier = Modifier.height(6.dp))

            Text(text = "प्रभारी अधिकारी: ${complaint.assignedOfficer}", fontSize = 11.sp, color = Color.Gray)
            if (complaint.resolutionNotes.isNotBlank()) {
                Text(text = "कार्रवाई टिपण्णी: ${complaint.resolutionNotes}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = statusColor)
            }

            if (userRole == "Admin") {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { showAdminDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("अधिकारी अपडेट / स्थिति बदलें", fontSize = 12.sp)
                }
            }
        }
    }

    if (showAdminDialog) {
        AlertDialog(
            onDismissRequest = { showAdminDialog = false },
            title = { Text("शिकायत स्थिति अपडेट करें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("टिकट: ${complaint.ticketNumber}", fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = actionNotes,
                        onValueChange = { actionNotes = it },
                        label = { Text("कार्रवाई / निवारण टिपण्णी") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            onUpdateStatus("In Progress", actionNotes)
                            showAdminDialog = false
                        }) { Text("प्रक्रियाधीन करें") }
                        Button(onClick = {
                            onUpdateStatus("Resolved", actionNotes)
                            showAdminDialog = false
                        }) { Text("निस्तारित मार्क करें") }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAdminDialog = false }) { Text("रद्द करें") }
            }
        )
    }
}
