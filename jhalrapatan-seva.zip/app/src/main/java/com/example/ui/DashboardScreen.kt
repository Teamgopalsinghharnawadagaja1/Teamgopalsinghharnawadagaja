package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*

data class NavTile(
    val titleHindi: String,
    val subtitleHindi: String,
    val icon: ImageVector,
    val color: Color,
    val targetTab: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateTab: (String) -> Unit
) {
    val userRole by viewModel.userRole.collectAsState()
    var showLoginDialog by remember { mutableStateOf(false) }
    var passwordInput by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf(false) }

    val complaints by viewModel.complaints.collectAsState()
    val developmentWorks by viewModel.developmentWorks.collectAsState()
    val emergencyContacts by viewModel.emergencyContacts.collectAsState()

    val totalComplaints = complaints.size
    val pendingComplaints = complaints.count { it.status == "Registered" || it.status == "In Progress" }
    val resolvedComplaints = complaints.count { it.status == "Resolved" }
    val totalWorks = developmentWorks.size
    val activeWorks = developmentWorks.count { it.status == "In Progress" }

    val gridTiles = listOf(
        NavTile("ग्राम व वार्ड", "ग्राम पंचायत, वार्ड व मतदान केंद्र", Icons.Default.LocationCity, Color(0xFF1565C0), "masters"),
        NavTile("विकास व बजट", "प्रगतिशील कार्य व फंड आवंटन", Icons.Default.Engineering, Color(0xFF2E7D32), "works"),
        NavTile("जनकल्याण योजनाएं", "समस्त राज्य व केंद्रीय योजनाएं", Icons.Default.Assignment, Color(0xFFE65100), "schemes"),
        NavTile("शिकायत निवारण", "ऑनलाइन शिकायत पंजीकरण व स्थिति", Icons.Default.ReportProblem, Color(0xFFC62828), "complaints"),
        NavTile("विभाग डायरेक्टरी", "अधिकारी व विभाग संपर्क", Icons.Default.ContactPhone, Color(0xFF6A1B9A), "departments"),
        NavTile("सार्वजनिक सुविधाएं", "विद्यालय, अस्पताल व हेल्पलाइन", Icons.Default.LocalHospital, Color(0xFF00838F), "facilities"),
        NavTile("GIS मानचित्र", "झालरापाटन भौगोलिक सूचना", Icons.Default.Map, Color(0xFF4E342E), "gis"),
        NavTile("विश्लेषण व रिपोर्ट", "जनसेवा आंकड़े एवं पीडीएफ", Icons.Default.BarChart, Color(0xFF37474F), "reports")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner Header (Royal Luxury Card)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("header_banner"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.5.dp, Color(0xFFD4AF37)),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                            )
                        )
                        .padding(20.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFD4AF37),
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.WorkspacePremium,
                                        contentDescription = null,
                                        tint = Color(0xFF0F172A),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "टीम गोपाल सिंह हरनावदा गजा",
                                    color = Color(0xFFD4AF37),
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "झालरापाटन - हरनावदा गजा जनसेवा व नागरिक सहायता पोर्टल",
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Role Switch Button
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (userRole == "Admin") Color(0xFFD4AF37) else Color.White.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, Color(0xFFD4AF37)),
                            modifier = Modifier
                                .clickable {
                                    if (userRole == "Citizen") {
                                        showLoginDialog = true
                                    } else {
                                        viewModel.logoutAdmin()
                                    }
                                }
                                .testTag("role_switch_chip")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (userRole == "Citizen") Icons.Default.Person else Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = if (userRole == "Admin") Color(0xFF0F172A) else Color(0xFFD4AF37),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (userRole == "Citizen") "नागरिक मोड" else "टीम Admin",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (userRole == "Admin") Color(0xFF0F172A) else Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Notice ticker
                    Surface(
                        color = Color(0xFFD4AF37).copy(alpha = 0.12f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(0.8.dp, Color(0xFFD4AF37).copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = Color(0xFFD4AF37),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "टीम गोपाल सिंह हरनावदा गजा हेल्पलाइन: 9166377972 | नागरिक सहायता एवं शिकायत पंजीकरण 24x7 उपलब्ध।",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Leader Royal Profile Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.2.dp, Color(0xFFD4AF37)),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Row(
                    modifier = Modifier
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFFFFFDF5), Color.White)
                            )
                        )
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        modifier = Modifier.size(54.dp),
                        shape = CircleShape,
                        color = Color(0xFF0F172A),
                        border = BorderStroke(1.5.dp, Color(0xFFD4AF37))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.PersonPin,
                                contentDescription = null,
                                tint = Color(0xFFD4AF37),
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "श्री गोपाल सिंह हरनावदा गजा",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = Color(0xFFB8860B),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = "जनसेवक एवं सामाजिक प्रतिनिधि - झालरापाटन",
                            fontSize = 12.sp,
                            color = Color(0xFFB8860B),
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "टीम मुख्यालय: हरनावदा गजा, झालरापाटन",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    Surface(
                        color = Color(0xFF0F172A),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFD4AF37))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneInTalk,
                                contentDescription = null,
                                tint = Color(0xFFD4AF37),
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "9166377972",
                                color = Color(0xFFD4AF37),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // AC-198 Jhalrapatan Verified Demographics & Administrative Boundary Summary
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFFD4AF37))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FactCheck,
                                contentDescription = null,
                                tint = Color(0xFFD4AF37),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AC-198 झालरापाटन: सत्यापित आँकड़े (Factbook)",
                                color = Color(0xFFD4AF37),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Surface(
                            color = Color(0xFF059669),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "सत्यापित रिकॉर्ड",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Villages Metric
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = Color.White.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("कुल गाँव", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                Text("304", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("Census 2011/Factbook", color = Color(0xFFD4AF37), fontSize = 9.sp)
                            }
                        }

                        // Towns Metric
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = Color.White.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("नगर / कस्बा", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                Text("3", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("शहरी निकाय क्षेत्र", color = Color(0xFFD4AF37), fontSize = 9.sp)
                            }
                        }

                        // Polling Stations Metric
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = Color.White.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("मतदान केंद्र", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                Text("296", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("CEO राज. 2024", color = Color(0xFFD4AF37), fontSize = 9.sp)
                            }
                        }

                        // Total Voters Metric
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = Color.White.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("मतदाता (2024)", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                Text("~3.00 L", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("निर्वाचक नामावली", color = Color(0xFFD4AF37), fontSize = 9.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "📌 परिसीमन व मैपिंग टिप्पणी: 2011 Census व Assembly Factbook के अनुसार AC-198 में 304 गांव व 3 टाउन हैं। वर्तमान में 2 पंचायत समितियों (झालरापाटन व पिड़ावा आंशिक) तथा 2 शहरी निकायों (झालरापाटन नगर पालिका के 25 वार्ड एवं झालावाड़ नगर परिषद के 7 वार्ड) की परिसीमन सीमाओं का पूर्ण मिलान किया गया है।",
                        color = Color.White.copy(alpha = 0.82f),
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Executive Quick Stats
        item {
            Text(
                text = "जनसेवा स्थिति एवं क्षेत्रीय विकास की झलक",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    title = "कुल शिकायतें",
                    value = "$totalComplaints",
                    subValue = "लंबित: $pendingComplaints",
                    icon = Icons.Default.AssignmentLate,
                    accentColor = Color(0xFFD32F2F),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "निस्तारित",
                    value = "$resolvedComplaints",
                    subValue = "सफलता: ${if (totalComplaints > 0) (resolvedComplaints * 100 / totalComplaints) else 100}%",
                    icon = Icons.Default.CheckCircle,
                    accentColor = Color(0xFF388E3C),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "विकास कार्य",
                    value = "$totalWorks",
                    subValue = "सक्रिय: $activeWorks",
                    icon = Icons.Default.Construction,
                    accentColor = Color(0xFFF57C00),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Navigation Grid
        item {
            Text(
                text = "मुख्य प्रशासनिक एवं नागरिक सेवाएं",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            
            // Grid layout using Column / Rows for smooth LazyColumn nesting
            val chunkedTiles = gridTiles.chunked(2)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (rowTiles in chunkedTiles) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        for (tile in rowTiles) {
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onNavigateTab(tile.targetTab) }
                                    .testTag("nav_tile_${tile.targetTab}"),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(0.8.dp, Color(0xFFE5C158).copy(alpha = 0.5f)),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(tile.color.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = tile.icon,
                                            contentDescription = tile.titleHindi,
                                            tint = tile.color,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = tile.titleHindi,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = Color(0xFF0F172A)
                                        )
                                        Text(
                                            text = tile.subtitleHindi,
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B),
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                        if (rowTiles.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // Emergency Directory Quick Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PhoneInTalk,
                            contentDescription = null,
                            tint = Color(0xFFC62828)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "आपातकालीन डायल सहयता (24x7)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFFB71C1C)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        EmergencyChip(name = "पुलिस", num = "112 / 100")
                        EmergencyChip(name = "एम्बुलेंस", num = "108")
                        EmergencyChip(name = "राजस्थान संपर्क", num = "181")
                        EmergencyChip(name = "अग्निशमन", num = "01432-240101")
                    }
                }
            }
        }

        // Disclaimer Note
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "अस्वीकरण (Disclaimer): यह ऐप 'टीम गोपाल सिंह हरनावदा गजा' द्वारा जनसेवा, नागरिक सहायता एवं क्षेत्रीय विकास की जानकारी हेतु संचालित गैर-सरकारी/सामाजिक सेवा ऐप है। यह किसी भी सरकारी विभाग का आधिकारिक ऐप नहीं है।",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    if (showLoginDialog) {
        AlertDialog(
            onDismissRequest = {
                showLoginDialog = false
                passwordInput = ""
                loginError = false
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, tint = Color(0xFFD4AF37))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("टीम Admin लॉगिन", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text("एडमिनिस्ट्रेटर मोड एक्सेस करने हेतु पासवर्ड दर्ज करें:", fontSize = 13.sp, color = Color(0xFF475569))
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = {
                            passwordInput = it
                            loginError = false
                        },
                        label = { Text("पासवर्ड") },
                        singleLine = true,
                        isError = loginError,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (loginError) {
                        Text("गलत पासवर्ड! कृपया सही एडमिन पासवर्ड दर्ज करें।", color = MaterialTheme.colorScheme.error, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (viewModel.verifyAdminPassword(passwordInput)) {
                            showLoginDialog = false
                            passwordInput = ""
                            loginError = false
                        } else {
                            loginError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A))
                ) {
                    Text("लॉगिन करें", color = Color(0xFFD4AF37), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showLoginDialog = false
                    passwordInput = ""
                    loginError = false
                }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    subValue: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color(0xFFE5C158).copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Surface(
                shape = CircleShape,
                color = accentColor.copy(alpha = 0.12f),
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF475569)
            )
            Text(
                text = subValue,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = accentColor
            )
        }
    }
}

@Composable
fun EmergencyChip(name: String, num: String) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(8.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = name, fontSize = 10.sp, color = Color.Gray)
            Text(text = num, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
        }
    }
}
