package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Royal Imperial & Metallic Gold Palette
val RoyalNavy = Color(0xFF0F172A)       // Imperial Deep Navy
val RoyalNavyLight = Color(0xFF1E293B)  // Dark Royal Blue Container
val RoyalGold = Color(0xFFD4AF37)        // Metallic Gold Accent
val RoyalGoldDark = Color(0xFFB8860B)    // Antique Deep Gold
val RoyalGoldLight = Color(0xFFFFF8E7)   // Soft Gold Tinted Background
val RoyalAmber = Color(0xFFC5A059)       // Classic Royal Amber
val RoyalCrimson = Color(0xFF800020)     // Imperial Crimson Accent

val IvoryBackground = Color(0xFFFAF8F5)  // Royal Ivory Canvas
val RoyalSurface = Color(0xFFFFFFFF)     // Clean White Cards
val RoyalCardBackground = Color(0xFFF7F5F0) // Subtle Gold-Toned Surface

val RoyalTextPrimary = Color(0xFF0F172A)
val RoyalTextSecondary = Color(0xFF475569)
val RoyalGoldBorder = Color(0xFFE5C158)

val SuccessGreen = Color(0xFF15803D)
val WarningAmber = Color(0xFFB45309)
val ErrorRed = Color(0xFFB91C1C)

