package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorksAndFundScreen(viewModel: MainViewModel) {
    var selectedSubTab by remember { mutableStateOf(0) } // 0: Development Works, 1: Fund Allocation
    val developmentWorks by viewModel.developmentWorks.collectAsState()
    val funds by viewModel.funds.collectAsState()

    var filterStatus by remember { mutableStateOf("All") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Tab(
                selected = selectedSubTab == 0,
                onClick = { selectedSubTab = 0 },
                text = { Text("विकास कार्य प्रगति") },
                icon = { Icon(Icons.Default.Engineering, contentDescription = null) }
            )
            Tab(
                selected = selectedSubTab == 1,
                onClick = { selectedSubTab = 1 },
                text = { Text("बजट एवं फंड आवंटन") },
                icon = { Icon(Icons.Default.AccountBalance, contentDescription = null) }
            )
        }

        if (selectedSubTab == 0) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All" to "सभी कार्य", "In Progress" to "प्रगति पर", "Completed" to "पूर्ण").forEach { (status, label) ->
                    FilterChip(
                        selected = filterStatus == status,
                        onClick = { filterStatus = status },
                        label = { Text(label) },
                        modifier = Modifier.testTag("filter_work_$status")
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            if (selectedSubTab == 0) {
                val filteredWorks = if (filterStatus == "All") developmentWorks else developmentWorks.filter { it.status == filterStatus }
                items(filteredWorks) { work ->
                    WorkCard(work = work)
                }
            } else {
                items(funds) { fund ->
                    FundCard(fund = fund)
                }
            }
        }
    }
}

@Composable
fun WorkCard(work: DevelopmentWorkEntity) {
    val statusColor = when (work.status) {
        "Completed" -> Color(0xFF2E7D32)
        "In Progress" -> Color(0xFFE65100)
        else -> Color(0xFF1565C0)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = work.workTitle,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    color = statusColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = if (work.status == "Completed") "पूर्ण" else "प्रगति पर (${work.completionPercentage}%)",
                        color = statusColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { work.completionPercentage / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp),
                color = statusColor,
                trackColor = Color.LightGray.copy(alpha = 0.4f)
            )

            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "स्थान: ${work.villageOrWard}", fontSize = 12.sp)
                Text(text = "स्वीकृत राशि: ₹${work.allocatedBudgetLakhs} लाख", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "कार्यकारी एजेंसी: ${work.executingAgency}", fontSize = 12.sp, color = Color.Gray)
                Text(text = "व्यय: ₹${work.spentBudgetLakhs} लाख", fontSize = 12.sp, color = Color.Gray)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "संवेदक/ठेकेदार: ${work.contractorName} (${work.contractorPhone})", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
            Text(text = "अवधि: ${work.startDate} से ${work.expectedCompletion}", fontSize = 11.sp, color = Color.Gray)
        }
    }
}

@Composable
fun FundCard(fund: FundRecordEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = fund.schemeOrHead,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "वर्ष ${fund.financialYear}",
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "स्वीकृत: ₹${fund.sanctionAmountLakhs} लाख", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Text(text = "प्राप्त: ₹${fund.receivedAmountLakhs} लाख", fontSize = 12.sp, color = Color(0xFF2E7D32))
                }
                Column {
                    Text(text = "उपयोग व्यय: ₹${fund.spentAmountLakhs} लाख", fontSize = 12.sp, color = Color(0xFFE65100))
                    Text(text = "शेष बजट: ₹${fund.balanceAmountLakhs} लाख", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "जारीकर्ता प्राधिकरण: ${fund.issuingAuthority}", fontSize = 11.sp, color = Color.Gray)
            Text(text = "विवरण: ${fund.remarks}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
        }
    }
}
