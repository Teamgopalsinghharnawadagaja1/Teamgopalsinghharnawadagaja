package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*

@Composable
fun DepartmentDirectoryScreen(viewModel: MainViewModel) {
    val departments by viewModel.departments.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("विभाग या अधिकारी का नाम खोजें...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            singleLine = true
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            val filteredDepts = departments.filter {
                it.deptNameHindi.contains(searchQuery, ignoreCase = true) ||
                it.headName.contains(searchQuery, ignoreCase = true)
            }

            items(filteredDepts) { dept ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = dept.deptNameHindi,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(text = dept.deptNameEnglish, fontSize = 12.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(text = "प्रभारी: ${dept.headName}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text(text = "पद: ${dept.designation}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                            Column {
                                Text(text = "संपर्क: ${dept.phone}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(text = "ईमेल: ${dept.email}", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "कार्यालय पता: ${dept.officeAddress}", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}
