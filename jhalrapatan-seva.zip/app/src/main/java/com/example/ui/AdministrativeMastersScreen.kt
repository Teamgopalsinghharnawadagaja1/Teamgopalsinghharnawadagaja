package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdministrativeMastersScreen(viewModel: MainViewModel) {
    var selectedSubTab by remember { mutableStateOf(0) } 
    // 0: Hierarchy & Blocks, 1: Gram Panchayats & Villages, 2: Urban Wards, 3: Polling Booths, 4: Representatives & Officers

    val panchayatSamitis by viewModel.panchayatSamitis.collectAsState()
    val urbanLocalBodies by viewModel.urbanLocalBodies.collectAsState()
    val villages by viewModel.villages.collectAsState()
    val panchayats by viewModel.panchayats.collectAsState()
    val wards by viewModel.wards.collectAsState()
    val pollingBooths by viewModel.pollingBooths.collectAsState()
    val representatives by viewModel.representatives.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedBlockFilter by remember { mutableStateOf("सभी") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Sub Header Tabs with Icons
        ScrollableTabRow(
            selectedTabIndex = selectedSubTab,
            edgePadding = 12.dp,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Tab(
                selected = selectedSubTab == 0,
                onClick = { selectedSubTab = 0 },
                text = { Text("मास्टर ढाँचा व ब्लॉक") },
                icon = { Icon(Icons.Default.AccountTree, contentDescription = null) }
            )
            Tab(
                selected = selectedSubTab == 1,
                onClick = { selectedSubTab = 1 },
                text = { Text("ग्राम पंचायत व गांव") },
                icon = { Icon(Icons.Default.HomeWork, contentDescription = null) }
            )
            Tab(
                selected = selectedSubTab == 2,
                onClick = { selectedSubTab = 2 },
                text = { Text("शहरी वार्ड निकाय") },
                icon = { Icon(Icons.Default.LocationCity, contentDescription = null) }
            )
            Tab(
                selected = selectedSubTab == 3,
                onClick = { selectedSubTab = 3 },
                text = { Text("मतदान केंद्र (GIS)") },
                icon = { Icon(Icons.Default.HowToVote, contentDescription = null) }
            )
            Tab(
                selected = selectedSubTab == 4,
                onClick = { selectedSubTab = 4 },
                text = { Text("जनप्रतिनिधि व अधिकारी") },
                icon = { Icon(Icons.Default.Badge, contentDescription = null) }
            )
        }

        // Search and Filter Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("खोजें (पंचायत, गांव, वार्ड, बूथ, अधिकारी)...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = null)
                        }
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("master_search_input"),
                singleLine = true
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            when (selectedSubTab) {
                0 -> {
                    // Master 9-Level Structure Card & Blocks
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.VerifiedUser,
                                        contentDescription = null,
                                        tint = Color(0xFFD4AF37),
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "AC-198 झालरापाटन प्रशासनिक ढाँचा (Master Structure)",
                                        color = Color(0xFFD4AF37),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "नोट: AC-198 की निर्वाचन सीमा में 2 पंचायत समितियाँ (झालरापाटन व पिड़ावा आंशिक) तथा 2 शहरी निकाय (नगर पालिका झालरापाटन व नगर परिषद झालावाड़ आंशिक) समाहित हैं।",
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }

                    item {
                        Text(
                            text = "पंचायत समितियाँ (Intermediate Panchayats in AC-198)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    items(panchayatSamitis) { samiti ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${samiti.nameHindi} (${samiti.nameEnglish})",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Surface(
                                        color = Color(0xFFE0F2FE),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "जिला: ${samiti.district}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF0369A1),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(text = "विकास अधिकारी (BDO): ${samiti.bdoName}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text(text = "संपर्क सूत्र: ${samiti.bdoPhone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                                Text(text = "कार्यालय: ${samiti.officeAddress}", fontSize = 12.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "सत्यापन: ${samiti.source} (${samiti.verificationStatus})",
                                    fontSize = 11.sp,
                                    color = Color(0xFF047857)
                                )
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "शहरी स्थानीय निकाय (Urban Local Bodies in AC-198)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    items(urbanLocalBodies) { ulb ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${ulb.nameHindi} (${ulb.nameEnglish})",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Surface(
                                        color = Color(0xFFFEF3C7),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = ulb.bodyType,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFFB45309),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(text = "अध्यक्ष / सभापति: ${ulb.headName}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text(text = "अधिशासी अधिकारी (EO) / आयुक्त: ${ulb.eoOrCommissioner}", fontSize = 13.sp)
                                Text(text = "हेल्पलाइन / फोन: ${ulb.contactPhone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                                Text(text = "कुल वार्ड: ${ulb.totalWards}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "सत्यापन स्त्रोत: ${ulb.source} (${ulb.verificationStatus})",
                                    fontSize = 11.sp,
                                    color = Color(0xFF047857)
                                )
                            }
                        }
                    }
                }
                1 -> {
                    // Gram Panchayats & Villages
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ग्राम पंचायत व राजस्व ग्राम निर्देशिका",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "कुल पंचायतें: ${panchayats.size}",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    // Block Selector Chips
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("सभी", "झालरापाटन", "पिड़ावा").forEach { block ->
                                FilterChip(
                                    selected = selectedBlockFilter == block,
                                    onClick = { selectedBlockFilter = block },
                                    label = { Text(block) }
                                )
                            }
                        }
                    }

                    val filteredPanchayats = panchayats.filter { gp ->
                        val matchesSearch = gp.nameHindi.contains(searchQuery, ignoreCase = true) ||
                                gp.sarpanchName.contains(searchQuery, ignoreCase = true) ||
                                gp.panchayatSamiti.contains(searchQuery, ignoreCase = true)
                        val matchesBlock = when (selectedBlockFilter) {
                            "झालरापाटन" -> gp.panchayatSamiti.contains("झालरापाटन")
                            "पिड़ावा" -> gp.panchayatSamiti.contains("पिड़ावा")
                            else -> true
                        }
                        matchesSearch && matchesBlock
                    }

                    items(filteredPanchayats) { gp ->
                        PanchayatCard(gp = gp, villagesInGp = villages.filter { it.gramPanchayat == gp.nameHindi })
                    }
                }
                2 -> {
                    // Urban Wards
                    item {
                        Text(
                            text = "शहरी वार्ड निर्देशिका (AC-198 परिसीमन)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    val filteredWards = wards.filter {
                        it.areaName.contains(searchQuery, ignoreCase = true) ||
                        it.councilorName.contains(searchQuery, ignoreCase = true) ||
                        it.urbanBodyName.contains(searchQuery, ignoreCase = true) ||
                        it.wardNumber.toString().contains(searchQuery)
                    }
                    items(filteredWards) { ward ->
                        WardCard(ward = ward)
                    }
                }
                3 -> {
                    // Polling Booths with GIS lat/long & source
                    item {
                        Text(
                            text = "विधानसभा क्षेत्र (198) झालरापाटन मतदान केंद्र व GIS डेटा",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    val filteredBooths = pollingBooths.filter {
                        it.boothName.contains(searchQuery, ignoreCase = true) ||
                        it.locationName.contains(searchQuery, ignoreCase = true) ||
                        it.panchayatSamitiOrUlb.contains(searchQuery, ignoreCase = true) ||
                        it.boothNumber.toString().contains(searchQuery)
                    }
                    items(filteredBooths) { booth ->
                        PollingBoothCard(booth = booth)
                    }
                }
                4 -> {
                    // Representatives & Key Officers
                    item {
                        Text(
                            text = "प्रमुख जनप्रतिनिधि एवं प्रशासनिक अधिकारी निर्देशिका",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    val filteredReps = representatives.filter {
                        it.name.contains(searchQuery, ignoreCase = true) ||
                        it.designation.contains(searchQuery, ignoreCase = true)
                    }
                    items(filteredReps) { rep ->
                        RepresentativeCard(rep = rep)
                    }
                }
            }
        }
    }
}

@Composable
fun PanchayatCard(gp: GramPanchayatEntity, villagesInGp: List<VillageEntity>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ग्राम पंचायत: ${gp.nameHindi} (${gp.nameEnglish})",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "ब्लॉक: ${gp.panchayatSamiti} | ${gp.lgdCode}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Medium
                    )
                }
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "आबादी: ${gp.population}",
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(text = "सरपंच: ${gp.sarpanchName}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text(text = "फ़ोन: ${gp.sarpanchPhone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                }
                Column {
                    Text(text = "ग्राम विकास अधिकारी (VDO): ${gp.gramVikasAdhikari}", fontSize = 13.sp)
                    Text(text = "फ़ोन: ${gp.gvaPhone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "कार्यालय: ${gp.officeAddress}", fontSize = 12.sp, color = Color.Gray)
            Text(text = "सत्यापन: ${gp.source} (${gp.verificationStatus})", fontSize = 11.sp, color = Color(0xFF047857))
            
            if (villagesInGp.isNotEmpty()) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                Text(text = "संबद्ध राजस्व गांव (${villagesInGp.size}):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                villagesInGp.forEach { v ->
                    Text(
                        text = "• ${v.nameHindi} (${v.nameEnglish}) - पटवारी वृत्त: ${v.patwariCircle} | रकबा: ${v.totalAreaHectares} हे. | परिवार: ${v.totalHouseholds}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                    )
                }
            }
        }
    }
}

@Composable
fun WardCard(ward: WardEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "वार्ड\n${ward.wardNumber}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(12.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = ward.urbanBodyName, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(text = ward.areaName, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(text = "पार्षद: ${ward.councilorName}", fontSize = 13.sp)
                Text(text = "संपर्क: ${ward.phone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(text = "कुल मतदाता: ${ward.totalVoters}", fontSize = 11.sp, color = Color.Gray)
                    Text(text = "ज़ोन: ${ward.municipalZone}", fontSize = 11.sp, color = Color.Gray)
                }
                Text(text = "स्त्रोत: ${ward.source} (${ward.verificationStatus})", fontSize = 10.sp, color = Color(0xFF047857))
            }
        }
    }
}

@Composable
fun PollingBoothCard(booth: PollingBoothEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "बूथ सं. ${booth.boothNumber}: ${booth.boothName}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = booth.gramPanchayatOrWard,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "स्थान: ${booth.locationName}", fontSize = 12.sp, color = Color.Gray)
            Text(text = "निकाय / ब्लॉक: ${booth.panchayatSamitiOrUlb}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (booth.latitude != 0.0 && booth.longitude != 0.0) {
                Text(text = "GIS निर्देशांक: ${booth.latitude}, ${booth.longitude}", fontSize = 11.sp, color = Color(0xFF0284C7))
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "कुल मतदाता: ${booth.totalVoters} (पुरुष: ${booth.maleVoters}, महिला: ${booth.femaleVoters})", fontSize = 11.sp)
                Text(text = "BLO: ${booth.bloName} (${booth.bloPhone})", fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
            Text(text = "स्त्रोत: ${booth.source} (${booth.verificationStatus})", fontSize = 10.sp, color = Color(0xFF047857))
        }
    }
}

@Composable
fun RepresentativeCard(rep: RepresentativeEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AccountBox,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = rep.name, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(text = "${rep.designation} (${rep.constituency})", fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
                Text(text = "फ़ोन: ${rep.phone}", fontSize = 12.sp)
                Text(text = "ईमेल: ${rep.email}", fontSize = 11.sp, color = Color.Gray)
                Text(text = "कार्यालय: ${rep.officeAddress}", fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}
