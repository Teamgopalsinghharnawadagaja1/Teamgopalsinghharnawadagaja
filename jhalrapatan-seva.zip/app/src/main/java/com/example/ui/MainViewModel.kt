package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: AdminRepository

    init {
        val dao = AppDatabase.getDatabase(application).adminDao()
        repository = AdminRepository(dao)
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            AppDatabase.ensureDataSeeded(dao)
        }
    }

    // Role state: "Citizen" or "Admin"
    private val _userRole = MutableStateFlow("Citizen")
    val userRole: StateFlow<String> = _userRole.asStateFlow()

    fun setUserRole(role: String) {
        _userRole.value = role
    }

    fun verifyAdminPassword(password: String): Boolean {
        return if (password == "Gopal@9672") {
            _userRole.value = "Admin"
            true
        } else {
            false
        }
    }

    fun logoutAdmin() {
        _userRole.value = "Citizen"
    }

    // Flow states
    val panchayatSamitis = repository.panchayatSamitis.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val urbanLocalBodies = repository.urbanLocalBodies.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val villages = repository.villages.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val panchayats = repository.panchayats.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val wards = repository.wards.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pollingBooths = repository.pollingBooths.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val departments = repository.departments.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val schemes = repository.schemes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val developmentWorks = repository.developmentWorks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val funds = repository.funds.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val complaints = repository.complaints.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val schools = repository.schools.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val healthCenters = repository.healthCenters.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val representatives = repository.representatives.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val emergencyContacts = repository.emergencyContacts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val suggestions = repository.suggestions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Complaint submission message
    private val _complaintSubmissionResult = MutableSharedFlow<String>()
    val complaintSubmissionResult = _complaintSubmissionResult.asSharedFlow()

    fun registerComplaint(
        name: String,
        phone: String,
        category: String,
        location: String,
        description: String
    ) {
        viewModelScope.launch {
            val randomNum = Random.nextInt(100, 999)
            val ticket = "JHL-2026-$randomNum"
            val complaint = ComplaintEntity(
                ticketNumber = ticket,
                citizenName = name.ifBlank { "नागरिक" },
                citizenPhone = phone.ifBlank { "9829000000" },
                category = category,
                villageOrWard = location.ifBlank { "झालरापाटन" },
                description = description,
                status = "Registered",
                assignedOfficer = "नोडल अधिकारी ($category विभाग)"
            )
            repository.submitComplaint(complaint)
            _complaintSubmissionResult.emit("आपकी शिकायत सफलतापूर्व दर्ज कर ली गई है। शिकायत टिकट संख्या: $ticket")
        }
    }

    fun updateComplaintStatus(complaint: ComplaintEntity, newStatus: String, notes: String) {
        viewModelScope.launch {
            val updated = complaint.copy(
                status = newStatus,
                resolutionNotes = notes,
                updatedTimestamp = System.currentTimeMillis()
            )
            repository.updateComplaintStatus(updated)
        }
    }

    fun submitSuggestion(title: String, category: String, details: String, name: String, phone: String) {
        viewModelScope.launch {
            val sug = CitizenSuggestionEntity(
                title = title,
                category = category,
                details = details,
                citizenName = name.ifBlank { "नागरिक" },
                citizenPhone = phone.ifBlank { "9829000000" }
            )
            repository.submitSuggestion(sug)
        }
    }
}
