package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*

@Composable
fun FacilitiesScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Schools, 1: Health, 2: Emergency Contacts
    val schools by viewModel.schools.collectAsState()
    val healthCenters by viewModel.healthCenters.collectAsState()
    val emergencyContacts by viewModel.emergencyContacts.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TabRow(selectedTabIndex = selectedTab, containerColor = MaterialTheme.colorScheme.surface) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("विद्यालय Master") }, icon = { Icon(Icons.Default.School, contentDescription = null) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("स्वास्थ्य केंद्र") }, icon = { Icon(Icons.Default.LocalHospital, contentDescription = null) })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("आपातकालीन डायरेक्टरी") }, icon = { Icon(Icons.Default.Phone, contentDescription = null) })
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    items(schools) { sch ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = sch.schoolName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text(text = "श्रेणी: ${sch.category} | स्थान: ${sch.location}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "प्रधानाचार्य: ${sch.principalName} (संपर्क: ${sch.phone})", fontSize = 12.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(top = 4.dp)) {
                                    Text(text = "विद्यार्थी: ${sch.totalStudents}", fontSize = 11.sp, color = Color.Gray)
                                    Text(text = "शिक्षक: ${sch.totalTeachers}", fontSize = 11.sp, color = Color.Gray)
                                    Text(text = "कंप्यूटर लैब: ${if (sch.computerLabAvailable) "उपलब्ध" else "उपलब्ध नहीं"}", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
                1 -> {
                    items(healthCenters) { hc ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = hc.centerName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                                Text(text = "प्रकार: ${hc.type} | स्थान: ${hc.location}", fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "प्रभारी: ${hc.inchargeDoctor} (${hc.phone})", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(top = 4.dp)) {
                                    Text(text = "बेड क्षमता: ${hc.bedCapacity}", fontSize = 11.sp, color = Color.Gray)
                                    Text(text = "एम्बुलेंस: ${if (hc.ambulance24x7) "24x7 उपलब्ध" else "नहीं"}", fontSize = 11.sp, color = Color.Gray)
                                }
                                Text(text = "समय: ${hc.timing}", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                }
                2 -> {
                    items(emergencyContacts) { ec ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = ec.titleHindi, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "विभाग: ${ec.department}", fontSize = 12.sp, color = Color.Gray)
                                    Text(text = ec.availability, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                                }
                                Button(
                                    onClick = {},
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                                ) {
                                    Icon(Icons.Default.Phone, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(ec.number, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
