package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*

@Composable
fun ReportsAndAnalyticsScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Executive Analytics, 1: Export / PDF, 2: Citizen Suggestions
    val context = LocalContext.current

    val complaints by viewModel.complaints.collectAsState()
    val works by viewModel.developmentWorks.collectAsState()
    val funds by viewModel.funds.collectAsState()
    val suggestions by viewModel.suggestions.collectAsState()

    var sugTitle by remember { mutableStateOf("") }
    var sugCategory by remember { mutableStateOf("विकास कार्य") }
    var sugDetails by remember { mutableStateOf("") }
    var sugName by remember { mutableStateOf("") }
    var sugPhone by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TabRow(selectedTabIndex = selectedTab, containerColor = MaterialTheme.colorScheme.surface) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("जनसेवा सांख्यिकी") }, icon = { Icon(Icons.Default.Analytics, contentDescription = null) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("रिपोर्ट Export") }, icon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null) })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("नागरिक सुझाव") }, icon = { Icon(Icons.Default.Lightbulb, contentDescription = null) })
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    item {
                        Text(text = "टीम जनसेवा एवं विकास डैशबोर्ड (Performance Dashboard)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = "शिकायत निस्तारण दर", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                val resolvedCount = complaints.count { it.status == "Resolved" }
                                val totalCount = complaints.size.coerceAtLeast(1)
                                val rate = (resolvedCount * 100) / totalCount
                                Text(text = "$rate% निस्तारित ($resolvedCount / ${complaints.size})", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                                LinearProgressIndicator(
                                    progress = { rate / 100f },
                                    modifier = Modifier.fillMaxWidth().height(8.dp).padding(top = 8.dp),
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = "विकास योजना बजट उपयोग स्थिति", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                val totalSanctioned = works.sumOf { it.allocatedBudgetLakhs }
                                val totalSpent = works.sumOf { it.spentBudgetLakhs }
                                Text(text = "कुल स्वीकृत: ₹$totalSanctioned लाख | व्यय: ₹$totalSpent लाख", fontSize = 13.sp)
                                val budgetUtilRate = if (totalSanctioned > 0) (totalSpent / totalSanctioned).toFloat() else 0f
                                LinearProgressIndicator(
                                    progress = { budgetUtilRate },
                                    modifier = Modifier.fillMaxWidth().height(8.dp).padding(top = 8.dp),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
                1 -> {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = "आधिकारिक डाटा Export एवं Backup Engine", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text(text = "संवैधानिक रिकॉर्ड्स को PDF / CSV प्रारूप में डाउनलोड करें", fontSize = 12.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = { Toast.makeText(context, "विकास कार्य रिपोर्ट PDF सफलतापूर्व जेनरेट की गई!", Toast.LENGTH_SHORT).show() },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("विकास कार्य प्रगति रिपोर्ट (PDF)")
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = { Toast.makeText(context, "ग्राम पंचायत एवं वार्ड Master Data CSV डाउनलोड पूर्ण!", Toast.LENGTH_SHORT).show() },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                ) {
                                    Icon(Icons.Default.TableChart, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("समस्त ग्राम व वार्ड डाटा Export (CSV)")
                                }
                            }
                        }
                    }
                }
                2 -> {
                    item {
                        Text(text = "नागरिक परामर्श एवं सुझाव सबमिशन", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(value = sugTitle, onValueChange = { sugTitle = it }, label = { Text("सुझाव का शीर्षक") }, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = sugDetails, onValueChange = { sugDetails = it }, label = { Text("सुझाव विवरण") }, modifier = Modifier.fillMaxWidth().height(80.dp))
                                OutlinedTextField(value = sugName, onValueChange = { sugName = it }, label = { Text("आपका नाम") }, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = sugPhone, onValueChange = { sugPhone = it }, label = { Text("फ़ोन नंबर") }, modifier = Modifier.fillMaxWidth())

                                Button(
                                    onClick = {
                                        if (sugTitle.isBlank()) {
                                            Toast.makeText(context, "कृपया शीर्षक दर्ज करें", Toast.LENGTH_SHORT).show()
                                        } else {
                                            viewModel.submitSuggestion(sugTitle, sugCategory, sugDetails, sugName, sugPhone)
                                            sugTitle = ""
                                            sugDetails = ""
                                            sugName = ""
                                            sugPhone = ""
                                            Toast.makeText(context, "आपका बहुमूल्य सुझाव जमा कर लिया गया है। धन्यवाद!", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("सुझाव जमा करें")
                                }
                            }
                        }
                    }

                    item {
                        Text(text = "पूर्व प्राप्त नागरिक सुझाव (${suggestions.size}):", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }

                    items(suggestions) { sug ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(text = sug.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(text = sug.details, fontSize = 12.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "प्रेषक: ${sug.citizenName} (${sug.citizenPhone})", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }
        }
    }
}
