package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

data class BottomNavItem(
    val route: String,
    val titleHindi: String,
    val icon: ImageVector
)

class MainActivity : ComponentActivity() {
    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppStructure(viewModel = mainViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppStructure(viewModel: MainViewModel) {
    var currentTab by remember { mutableStateOf("dashboard") }

    val navItems = listOf(
        BottomNavItem("dashboard", "मुख्य पृष्ठ", Icons.Default.Home),
        BottomNavItem("masters", "ग्राम/वार्ड Master", Icons.Default.LocationCity),
        BottomNavItem("works", "विकास व बजट", Icons.Default.Engineering),
        BottomNavItem("schemes", "योजनाएं", Icons.Default.Assignment),
        BottomNavItem("complaints", "शिकायत निवारण", Icons.Default.ReportProblem)
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            Surface(
                shadowElevation = 6.dp,
                color = MaterialTheme.colorScheme.primary
            ) {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = when (currentTab) {
                                "dashboard" -> "टीम गोपाल सिंह हरनावदा गजा"
                                "masters" -> "ग्राम, वार्ड व बूथ निर्देशिका"
                                "works" -> "विकास कार्य एवं बजट आवंटन"
                                "schemes" -> "जनकल्याणकारी योजनाएं"
                                "complaints" -> "जनसमस्या व नागरिक सहायता"
                                "departments" -> "विभाग व अधिकारी डायरेक्टरी"
                                "facilities" -> "सार्वजनिक सुविधाएं व आपातकालीन"
                                "gis" -> "GIS जीआईएस सूचना मानचित्र"
                                "reports" -> "जनसेवा विश्लेषण व रिपोर्ट"
                                else -> "टीम गोपाल सिंह हरनावदा गजा"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                        )
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = androidx.compose.ui.graphics.Color(0xFFD4AF37) // Metallic Gold
                    )
                )
            }
        },
        bottomBar = {
            Surface(
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    navItems.forEach { item ->
                        val isSelected = currentTab == item.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentTab = item.route },
                            icon = { Icon(imageVector = item.icon, contentDescription = item.titleHindi) },
                            label = {
                                Text(
                                    text = item.titleHindi,
                                    fontWeight = if (isSelected) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = androidx.compose.ui.graphics.Color(0xFFFFF8E7),
                                unselectedIconColor = androidx.compose.ui.graphics.Color(0xFF64748B),
                                unselectedTextColor = androidx.compose.ui.graphics.Color(0xFF64748B)
                            ),
                            modifier = Modifier.testTag("nav_${item.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                "dashboard" -> DashboardScreen(viewModel = viewModel, onNavigateTab = { currentTab = it })
                "masters" -> AdministrativeMastersScreen(viewModel = viewModel)
                "works" -> WorksAndFundScreen(viewModel = viewModel)
                "schemes" -> SchemesCatalogueScreen(viewModel = viewModel)
                "complaints" -> ComplaintsScreen(viewModel = viewModel)
                "departments" -> DepartmentDirectoryScreen(viewModel = viewModel)
                "facilities" -> FacilitiesScreen(viewModel = viewModel)
                "gis" -> GisMapScreen(viewModel = viewModel)
                "reports" -> ReportsAndAnalyticsScreen(viewModel = viewModel)
                else -> DashboardScreen(viewModel = viewModel, onNavigateTab = { currentTab = it })
            }
        }
    }
}

