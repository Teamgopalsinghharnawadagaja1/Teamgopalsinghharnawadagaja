package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "panchayat_samitis")
data class PanchayatSamitiEntity(
    @PrimaryKey val id: String,
    val nameHindi: String,
    val nameEnglish: String,
    val assemblyNo: String = "AC-198 (झालरापाटन)",
    val district: String = "झालावाड़",
    val bdoName: String,
    val bdoPhone: String,
    val officeAddress: String,
    val source: String = "ई-ग्राम राजस्थान / पंचायती राज विभाग",
    val verificationStatus: String = "क्रॉस-चेक व सत्यापित"
)

@Entity(tableName = "urban_local_bodies")
data class UrbanLocalBodyEntity(
    @PrimaryKey val id: String,
    val nameHindi: String,
    val nameEnglish: String,
    val bodyType: String, // "नगर पालिका", "नगर परिषद"
    val assemblyNo: String = "AC-198 (झालरापाटन)",
    val totalWards: Int,
    val headName: String, // अध्यक्ष / सभापति
    val eoOrCommissioner: String, // EO / Commissioner
    val contactPhone: String,
    val officeAddress: String,
    val source: String = "स्वायत्त शासन विभाग / राज्य निर्वाचन आयोग",
    val verificationStatus: String = "क्रॉस-चेक व सत्यापित"
)

@Entity(tableName = "villages")
data class VillageEntity(
    @PrimaryKey val id: String,
    val nameHindi: String,
    val nameEnglish: String,
    val assemblyNo: String = "AC-198 (झालरापाटन)",
    val panchayatSamiti: String, // e.g. "झालरापाटन", "पिड़ावा"
    val gramPanchayat: String,
    val block: String,
    val tehsildar: String,
    val patwariCircle: String,
    val lgdCode: String = "",
    val population: Int,
    val totalHouseholds: Int,
    val totalAreaHectares: Double,
    val latitude: Double,
    val longitude: Double,
    val source: String = "ई-ग्राम राजस्थान / जनगणना व राजस्व रिकॉर्ड",
    val verificationStatus: String = "क्रॉस-चेक व सत्यापित",
    val verifiedDate: String = "2024-2026"
)

@Entity(tableName = "gram_panchayats")
data class GramPanchayatEntity(
    @PrimaryKey val id: String,
    val nameHindi: String,
    val nameEnglish: String,
    val assemblyNo: String = "AC-198 (झालरापाटन)",
    val panchayatSamiti: String, // "झालरापाटन" या "पिड़ावा"
    val lgdCode: String = "",
    val sarpanchName: String,
    val sarpanchPhone: String,
    val gramVikasAdhikari: String,
    val gvaPhone: String,
    val totalVillages: Int,
    val population: Int,
    val officeAddress: String,
    val source: String = "ई-ग्राम राजस्थान पोर्टल (E-Gram Portal)",
    val verificationStatus: String = "क्रॉस-चेक व सत्यापित",
    val verifiedDate: String = "2024-2026"
)

@Entity(tableName = "wards")
data class WardEntity(
    @PrimaryKey val id: String,
    val urbanBodyName: String = "नगर पालिका झालरापाटन", // "नगर पालिका झालरापाटन" या "नगर परिषद झालावाड़"
    val wardNumber: Int,
    val areaName: String,
    val councilorName: String,
    val phone: String,
    val totalVoters: Int,
    val municipalZone: String,
    val source: String = "राज्य निर्वाचन आयोग / नगर निकाय परिसीमन",
    val verificationStatus: String = "क्रॉस-चेक व सत्यापित",
    val verifiedDate: String = "2024-2026"
)

@Entity(tableName = "polling_booths")
data class PollingBoothEntity(
    @PrimaryKey val id: String,
    val assemblyNo: String = "AC-198 (झालरापाटन)",
    val panchayatSamitiOrUlb: String, // e.g. "पंचायत समिति झालरापाटन", "पंचायत समिति पिड़ावा", "नगर पालिका झालरापाटन"
    val boothNumber: Int,
    val boothName: String,
    val locationName: String,
    val totalVoters: Int,
    val maleVoters: Int,
    val femaleVoters: Int,
    val bloName: String,
    val bloPhone: String,
    val gramPanchayatOrWard: String,
    val latitude: Double = 24.535,
    val longitude: Double = 76.170,
    val source: String = "भारत निर्वाचन आयोग / CEO राजस्थान AC-198 निर्वाचक नामावली",
    val verificationStatus: String = "क्रॉस-चेक व सत्यापित"
)

@Entity(tableName = "departments")
data class DepartmentEntity(
    @PrimaryKey val id: String,
    val deptNameHindi: String,
    val deptNameEnglish: String,
    val headName: String,
    val designation: String,
    val phone: String,
    val email: String,
    val officeAddress: String,
    val totalActiveSchemes: Int
)

@Entity(tableName = "schemes")
data class SchemeEntity(
    @PrimaryKey val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val departmentId: String,
    val departmentName: String,
    val category: String, // Health, Agriculture, Housing, Social Welfare, Education
    val eligibility: String,
    val benefits: String,
    val requiredDocuments: String,
    val helpline: String,
    val websiteUrl: String,
    val isActive: Boolean = true
)

@Entity(tableName = "development_works")
data class DevelopmentWorkEntity(
    @PrimaryKey val id: String,
    val workTitle: String,
    val villageOrWard: String,
    val department: String,
    val allocatedBudgetLakhs: Double,
    val spentBudgetLakhs: Double,
    val sanctionYear: String,
    val executingAgency: String,
    val status: String, // Completed, In Progress, Sanctioned, On Hold
    val completionPercentage: Int,
    val contractorName: String,
    val contractorPhone: String,
    val startDate: String,
    val expectedCompletion: String
)

@Entity(tableName = "fund_records")
data class FundRecordEntity(
    @PrimaryKey val id: String,
    val financialYear: String,
    val schemeOrHead: String,
    val sanctionAmountLakhs: Double,
    val receivedAmountLakhs: Double,
    val spentAmountLakhs: Double,
    val balanceAmountLakhs: Double,
    val issuingAuthority: String,
    val remarks: String
)

@Entity(tableName = "complaints")
data class ComplaintEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ticketNumber: String,
    val citizenName: String,
    val citizenPhone: String,
    val category: String, // Electricity, Water, Road, Sanitation, Scheme, Others
    val villageOrWard: String,
    val description: String,
    val status: String, // Registered, Assigned, In Progress, Resolved, Rejected
    val createdTimestamp: Long = System.currentTimeMillis(),
    val updatedTimestamp: Long = System.currentTimeMillis(),
    val assignedOfficer: String,
    val resolutionNotes: String = ""
)

@Entity(tableName = "schools")
data class SchoolEntity(
    @PrimaryKey val id: String,
    val schoolName: String,
    val location: String,
    val category: String, // Primary, Upper Primary, Secondary, Higher Secondary, College
    val principalName: String,
    val phone: String,
    val totalStudents: Int,
    val totalTeachers: Int,
    val computerLabAvailable: Boolean
)

@Entity(tableName = "health_centers")
data class HealthCenterEntity(
    @PrimaryKey val id: String,
    val centerName: String,
    val type: String, // Sub-center, PHC, CHC, District Hospital
    val location: String,
    val inchargeDoctor: String,
    val phone: String,
    val bedCapacity: Int,
    val ambulance24x7: Boolean,
    val timing: String
)

@Entity(tableName = "representatives")
data class RepresentativeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val designation: String, // MP, MLA, District Collector, Tehsildar, SDM, BDO, Municipal Chairman
    val constituency: String,
    val phone: String,
    val officeAddress: String,
    val email: String
)

@Entity(tableName = "emergency_contacts")
data class EmergencyContactEntity(
    @PrimaryKey val id: String,
    val titleHindi: String,
    val number: String,
    val department: String,
    val availability: String
)

@Entity(tableName = "citizen_suggestions")
data class CitizenSuggestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val details: String,
    val citizenName: String,
    val citizenPhone: String,
    val timestamp: Long = System.currentTimeMillis()
)
