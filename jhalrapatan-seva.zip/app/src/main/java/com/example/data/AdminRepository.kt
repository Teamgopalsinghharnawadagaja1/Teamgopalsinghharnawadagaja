package com.example.data

import kotlinx.coroutines.flow.Flow

class AdminRepository(private val dao: AdminDao) {
    val panchayatSamitis: Flow<List<PanchayatSamitiEntity>> = dao.getAllPanchayatSamitis()
    val urbanLocalBodies: Flow<List<UrbanLocalBodyEntity>> = dao.getAllUrbanLocalBodies()
    val villages: Flow<List<VillageEntity>> = dao.getAllVillages()
    val panchayats: Flow<List<GramPanchayatEntity>> = dao.getAllGramPanchayats()
    val wards: Flow<List<WardEntity>> = dao.getAllWards()
    val pollingBooths: Flow<List<PollingBoothEntity>> = dao.getAllPollingBooths()
    val departments: Flow<List<DepartmentEntity>> = dao.getAllDepartments()
    val schemes: Flow<List<SchemeEntity>> = dao.getAllSchemes()
    val developmentWorks: Flow<List<DevelopmentWorkEntity>> = dao.getAllDevelopmentWorks()
    val funds: Flow<List<FundRecordEntity>> = dao.getAllFunds()
    val complaints: Flow<List<ComplaintEntity>> = dao.getAllComplaints()
    val schools: Flow<List<SchoolEntity>> = dao.getAllSchools()
    val healthCenters: Flow<List<HealthCenterEntity>> = dao.getAllHealthCenters()
    val representatives: Flow<List<RepresentativeEntity>> = dao.getAllRepresentatives()
    val emergencyContacts: Flow<List<EmergencyContactEntity>> = dao.getAllEmergencyContacts()
    val suggestions: Flow<List<CitizenSuggestionEntity>> = dao.getAllSuggestions()

    suspend fun submitComplaint(complaint: ComplaintEntity) {
        dao.insertComplaint(complaint)
    }

    suspend fun updateComplaintStatus(complaint: ComplaintEntity) {
        dao.updateComplaint(complaint)
    }

    suspend fun submitSuggestion(suggestion: CitizenSuggestionEntity) {
        dao.insertSuggestion(suggestion)
    }
}
