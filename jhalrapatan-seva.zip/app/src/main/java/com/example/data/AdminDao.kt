package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AdminDao {
    // Panchayat Samitis (Blocks)
    @Query("SELECT * FROM panchayat_samitis ORDER BY nameHindi ASC")
    fun getAllPanchayatSamitis(): Flow<List<PanchayatSamitiEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPanchayatSamitis(samitis: List<PanchayatSamitiEntity>)

    // Urban Local Bodies
    @Query("SELECT * FROM urban_local_bodies ORDER BY nameHindi ASC")
    fun getAllUrbanLocalBodies(): Flow<List<UrbanLocalBodyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUrbanLocalBodies(bodies: List<UrbanLocalBodyEntity>)

    // Count helpers
    @Query("SELECT COUNT(*) FROM gram_panchayats")
    suspend fun getPanchayatCount(): Int

    @Query("SELECT COUNT(*) FROM wards")
    suspend fun getWardCount(): Int

    @Query("SELECT COUNT(*) FROM villages")
    suspend fun getVillageCount(): Int

    @Query("SELECT COUNT(*) FROM polling_booths")
    suspend fun getPollingBoothCount(): Int

    // Villages
    @Query("SELECT * FROM villages ORDER BY nameHindi ASC")
    fun getAllVillages(): Flow<List<VillageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVillages(villages: List<VillageEntity>)

    // Gram Panchayats
    @Query("SELECT * FROM gram_panchayats ORDER BY nameHindi ASC")
    fun getAllGramPanchayats(): Flow<List<GramPanchayatEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGramPanchayats(panchayats: List<GramPanchayatEntity>)

    // Wards
    @Query("SELECT * FROM wards ORDER BY wardNumber ASC")
    fun getAllWards(): Flow<List<WardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWards(wards: List<WardEntity>)

    // Polling Booths
    @Query("SELECT * FROM polling_booths ORDER BY boothNumber ASC")
    fun getAllPollingBooths(): Flow<List<PollingBoothEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPollingBooths(booths: List<PollingBoothEntity>)

    // Departments
    @Query("SELECT * FROM departments ORDER BY deptNameHindi ASC")
    fun getAllDepartments(): Flow<List<DepartmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDepartments(departments: List<DepartmentEntity>)

    // Schemes
    @Query("SELECT * FROM schemes ORDER BY titleHindi ASC")
    fun getAllSchemes(): Flow<List<SchemeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchemes(schemes: List<SchemeEntity>)

    // Development Works
    @Query("SELECT * FROM development_works ORDER BY workTitle ASC")
    fun getAllDevelopmentWorks(): Flow<List<DevelopmentWorkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevelopmentWorks(works: List<DevelopmentWorkEntity>)

    // Funds
    @Query("SELECT * FROM fund_records ORDER BY financialYear DESC")
    fun getAllFunds(): Flow<List<FundRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFunds(funds: List<FundRecordEntity>)

    // Complaints
    @Query("SELECT * FROM complaints ORDER BY createdTimestamp DESC")
    fun getAllComplaints(): Flow<List<ComplaintEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComplaint(complaint: ComplaintEntity)

    @Update
    suspend fun updateComplaint(complaint: ComplaintEntity)

    // Schools
    @Query("SELECT * FROM schools ORDER BY schoolName ASC")
    fun getAllSchools(): Flow<List<SchoolEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchools(schools: List<SchoolEntity>)

    // Health
    @Query("SELECT * FROM health_centers ORDER BY centerName ASC")
    fun getAllHealthCenters(): Flow<List<HealthCenterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHealthCenters(healthCenters: List<HealthCenterEntity>)

    // Representatives
    @Query("SELECT * FROM representatives")
    fun getAllRepresentatives(): Flow<List<RepresentativeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepresentatives(reps: List<RepresentativeEntity>)

    // Emergency
    @Query("SELECT * FROM emergency_contacts")
    fun getAllEmergencyContacts(): Flow<List<EmergencyContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmergencyContacts(contacts: List<EmergencyContactEntity>)

    // Suggestions
    @Query("SELECT * FROM citizen_suggestions ORDER BY timestamp DESC")
    fun getAllSuggestions(): Flow<List<CitizenSuggestionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSuggestion(suggestion: CitizenSuggestionEntity)
}
